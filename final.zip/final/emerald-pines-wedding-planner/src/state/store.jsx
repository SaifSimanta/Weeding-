import React, { createContext, useContext, useMemo, useReducer } from "react";

/* ------------------------------------------------------------------ */
/*  Shared fictional seed data                                        */
/* ------------------------------------------------------------------ */

const today = new Date();
const addDays = (d, n) => {
  const x = new Date(d);
  x.setDate(x.getDate() + n);
  return x;
};
const iso = (d) => new Date(d).toISOString().slice(0, 10);

// Pick next-business-day baseline anchored in 2026
const base2026 = new Date("2026-06-15T00:00:00");

export const VENUES = [
  { id: "pine-grove", name: "Pine Grove Lawn", capacity: 180, kind: "Outdoor" },
  { id: "ivory-hall", name: "Ivory Hall", capacity: 220, kind: "Indoor" },
  { id: "garden-chapel", name: "Garden Chapel", capacity: 120, kind: "Outdoor" },
  { id: "emerald-terrace", name: "Emerald Terrace", capacity: 90, kind: "Rooftop" },
];

const businessDayDue = (fromDate) => {
  let d = new Date(fromDate);
  let added = 0;
  while (added < 3) {
    d = addDays(d, 1);
    const wd = d.getDay();
    if (wd !== 0 && wd !== 6) added += 1;
  }
  return iso(d);
};

const SEED = () => {
  const now = new Date();

  const requests = [
    {
      id: "REQ-10241",
      reference: "EP-10241",
      client: {
        name: "Amelia & Jonathan Caldwell",
        phone: "(555) 207-1182",
        email: "amelia.caldwell@example.com",
        address: "48 Magnolia Lane, Ashford, VT",
      },
      venueId: "pine-grove",
      weddingDate: iso(new Date("2026-08-22")),
      guestCount: 140,
      cultural: { enabled: true, details: "Traditional tea ceremony with family blessings." },
      silentDisco: { enabled: true, details: "150 headsets, 3 channels for after-dinner dancing." },
      otherFacilities: "Vintage car arrival, floral arbour, golf-cart shuttle for elderly guests.",
      services: "Plated dinner, vegetarian & kosher options, late-night pastry station.",
      status: "under_review",
      submittedAt: iso(addDays(now, -2)),
      reviewDueAt: businessDayDue(addDays(now, -2)),
      deposit: { paid: true, amount: 100, reference: "PMT-77124", date: iso(addDays(now, -2)) },
      findings: [],
      coordinatorMessage: "",
      reservation: null,
      refund: null,
      timeline: [
        { label: "Plan submitted", at: iso(addDays(now, -2)) },
        { label: "Deposit received", at: iso(addDays(now, -2)) },
        { label: "Under review", at: iso(addDays(now, -2)) },
      ],
    },
    {
      id: "REQ-10242",
      reference: "EP-10242",
      client: {
        name: "Sofia Mendes",
        phone: "(555) 441-2290",
        email: "sofia.mendes@example.com",
        address: "12 Rosewood Court, Burlington, VT",
      },
      venueId: "ivory-hall",
      weddingDate: iso(new Date("2026-09-12")),
      guestCount: 210,
      cultural: { enabled: false, details: "" },
      silentDisco: { enabled: false, details: "" },
      otherFacilities: "Grand piano on stage, uplighting, ice sculpture display.",
      services: "Four-course plated dinner, premium bar package.",
      status: "needs_info",
      submittedAt: iso(addDays(now, -4)),
      reviewDueAt: businessDayDue(addDays(now, -4)),
      deposit: { paid: true, amount: 100, reference: "PMT-77125", date: iso(addDays(now, -4)) },
      findings: [
        { item: "Grand piano", fulfillable: "unclear", notes: "Verify tuning schedule." },
      ],
      coordinatorMessage:
        "Could you confirm if the ice sculpture must remain throughout the evening? This affects our refrigeration staging.",
      reservation: null,
      refund: null,
      timeline: [
        { label: "Plan submitted", at: iso(addDays(now, -4)) },
        { label: "Deposit received", at: iso(addDays(now, -4)) },
        { label: "Under review", at: iso(addDays(now, -4)) },
        { label: "More information requested", at: iso(addDays(now, -1)) },
      ],
    },
    {
      id: "REQ-10243",
      reference: "EP-10243",
      client: {
        name: "Priya & Rohan Shah",
        phone: "(555) 882-7719",
        email: "priya.shah@example.com",
        address: "901 Birchwood Ave, Montpelier, VT",
      },
      venueId: "garden-chapel",
      weddingDate: iso(new Date("2026-07-04")),
      guestCount: 110,
      cultural: { enabled: true, details: "Baraat procession, haldi, and sangeet night." },
      silentDisco: { enabled: false, details: "" },
      otherFacilities: "Mandap setup, henna station, cultural catering bay.",
      services: "Full Indian menu, live tabla & dhol players.",
      status: "confirmed",
      submittedAt: iso(addDays(now, -14)),
      reviewDueAt: businessDayDue(addDays(now, -14)),
      deposit: { paid: true, amount: 100, reference: "PMT-77123", date: iso(addDays(now, -14)) },
      findings: [
        { item: "Mandap setup", fulfillable: "yes", notes: "Confirmed with decor partner." },
        { item: "Baraat route", fulfillable: "yes", notes: "Pine Drive to Chapel." },
      ],
      coordinatorMessage: "",
      reservation: {
        reference: "RSV-55012",
        confirmedAt: iso(addDays(now, -9)),
        method: "Email agreement",
      },
      refund: null,
      timeline: [
        { label: "Plan submitted", at: iso(addDays(now, -14)) },
        { label: "Deposit received", at: iso(addDays(now, -14)) },
        { label: "Under review", at: iso(addDays(now, -14)) },
        { label: "Reservation confirmed", at: iso(addDays(now, -9)) },
      ],
    },
    {
      id: "REQ-10244",
      reference: "EP-10244",
      client: {
        name: "Noah & Emily Fletcher",
        phone: "(555) 110-6633",
        email: "noah.fletcher@example.com",
        address: "7 Pine Ridge Dr, Stowe, VT",
      },
      venueId: "emerald-terrace",
      weddingDate: iso(new Date("2026-05-30")),
      guestCount: 80,
      cultural: { enabled: false, details: "" },
      silentDisco: { enabled: true, details: "80 headsets, 2 channels." },
      otherFacilities: "Rooftop fireworks display, custom neon signage.",
      services: "Cocktail reception with passed hors d'oeuvres.",
      status: "cannot_fulfill",
      submittedAt: iso(addDays(now, -7)),
      reviewDueAt: businessDayDue(addDays(now, -7)),
      deposit: { paid: true, amount: 100, reference: "PMT-77122", date: iso(addDays(now, -7)) },
      findings: [
        { item: "Fireworks display", fulfillable: "no", notes: "Local ordinance prohibits aerial fireworks." },
      ],
      coordinatorMessage:
        "Unfortunately rooftop fireworks are not permitted under local regulation. We are unable to fulfil this requirement.",
      reservation: null,
      refund: {
        amount: 100,
        reference: "RFD-33002",
        status: "pending",
        reason: "Fireworks display cannot be provided.",
        requestedAt: iso(addDays(now, -2)),
      },
      timeline: [
        { label: "Plan submitted", at: iso(addDays(now, -7)) },
        { label: "Deposit received", at: iso(addDays(now, -7)) },
        { label: "Under review", at: iso(addDays(now, -7)) },
        { label: "Marked cannot fulfil", at: iso(addDays(now, -2)) },
        { label: "Refund pending", at: iso(addDays(now, -2)) },
      ],
    },
    {
      id: "REQ-DRAFT-01",
      reference: "DRAFT-01",
      client: {
        name: "Harper Lin",
        phone: "(555) 300-9988",
        email: "harper.lin@example.com",
        address: "",
      },
      venueId: "pine-grove",
      weddingDate: iso(new Date("2026-10-17")),
      guestCount: 160,
      cultural: { enabled: false, details: "" },
      silentDisco: { enabled: false, details: "" },
      otherFacilities: "",
      services: "",
      status: "draft",
      submittedAt: null,
      reviewDueAt: null,
      deposit: { paid: false, amount: 0, reference: null, date: null },
      findings: [],
      coordinatorMessage: "",
      reservation: null,
      refund: null,
      timeline: [{ label: "Draft saved", at: iso(addDays(now, -1)) }],
    },
  ];

  const staff = [
    { id: "STF-01", name: "Elena Rhodes", email: "elena.rhodes@emeraldpines.club", role: "Coordinator", active: true },
    { id: "STF-02", name: "Marcus Hale", email: "marcus.hale@emeraldpines.club", role: "Coordinator", active: true },
    { id: "STF-03", name: "Yasmin Park", email: "yasmin.park@emeraldpines.club", role: "Administrator", active: true },
    { id: "STF-04", name: "Daniel Okafor", email: "daniel.okafor@emeraldpines.club", role: "Coordinator", active: false },
  ];

  const closures = [
    { id: "CLO-01", date: iso(new Date("2026-07-04")), reason: "Pre-booked: Shah wedding", venueId: "garden-chapel", system: true },
    { id: "CLO-02", date: iso(new Date("2026-12-25")), reason: "Holiday — Club closed", venueId: null, system: false },
    { id: "CLO-03", date: iso(new Date("2026-08-15")), reason: "Private member event", venueId: "ivory-hall", system: false },
  ];

  const inquiries = [
    {
      id: "INQ-2201",
      name: "Clara Doyle",
      email: "clara.doyle@example.com",
      subject: "Vegan menu options",
      message: "Do you offer fully vegan tasting menus for weddings over 100 guests?",
      createdAt: iso(addDays(now, -1)),
      status: "open",
      reply: "",
      requestRef: null,
    },
  ];

  return {
    activeView: "client",
    activeRequestId: "REQ-10241",
    session: null,
    requests,
    staff,
    closures,
    inquiries,
    presentation: {
      paymentOutcome: "success", // success | declined | unknown
      refundOutcome: "completed", // pending | completed | failed | unknown
      forceConflict: false,
    },
  };
};

/* ------------------------------------------------------------------ */
/*  Reducer                                                           */
/* ------------------------------------------------------------------ */

const AppCtx = createContext(null);

function reducer(state, action) {
  switch (action.type) {
    case "RESET":
      return { ...SEED(), session: state.session };
    case "SET_LOGIN":
      return { ...state, session: action.session };
    case "LOGOUT":
      return { ...state, session: null };
    case "SET_VIEW":
      return { ...state, activeView: action.view };
    case "SET_ACTIVE_REQUEST":
      return { ...state, activeRequestId: action.id };
    case "SET_PRESENTATION":
      return { ...state, presentation: { ...state.presentation, ...action.patch } };
    case "UPSERT_REQUEST": {
      const existing = state.requests.find((r) => r.id === action.request.id);
      const requests = existing
        ? state.requests.map((r) => (r.id === action.request.id ? action.request : r))
        : [action.request, ...state.requests];
      return { ...state, requests, activeRequestId: action.request.id };
    }
    case "PATCH_REQUEST": {
      const requests = state.requests.map((r) =>
        r.id === action.id ? { ...r, ...action.patch } : r,
      );
      return { ...state, requests };
    }
    case "APPEND_TIMELINE": {
      const requests = state.requests.map((r) =>
        r.id === action.id
          ? { ...r, timeline: [...r.timeline, { label: action.label, at: iso(new Date()) }] }
          : r,
      );
      return { ...state, requests };
    }
    case "UPSERT_STAFF": {
      const existing = state.staff.find((s) => s.id === action.staff.id);
      const staff = existing
        ? state.staff.map((s) => (s.id === action.staff.id ? action.staff : s))
        : [...state.staff, action.staff];
      return { ...state, staff };
    }
    case "DEACTIVATE_STAFF":
      return {
        ...state,
        staff: state.staff.map((s) => (s.id === action.id ? { ...s, active: false } : s)),
      };
    case "ADD_CLOSURE":
      return { ...state, closures: [...state.closures, action.closure] };
    case "UPDATE_CLOSURE":
      return {
        ...state,
        closures: state.closures.map((c) => (c.id === action.closure.id ? action.closure : c)),
      };
    case "REMOVE_CLOSURE":
      return { ...state, closures: state.closures.filter((c) => c.id !== action.id) };
    case "ADD_INQUIRY":
      return { ...state, inquiries: [action.inquiry, ...state.inquiries] };
    case "PATCH_INQUIRY":
      return {
        ...state,
        inquiries: state.inquiries.map((i) =>
          i.id === action.id ? { ...i, ...action.patch } : i,
        ),
      };
    default:
      return state;
  }
}

export function AppStateProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, null, SEED);
  const value = useMemo(() => ({ state, dispatch }), [state]);
  return <AppCtx.Provider value={value}>{children}</AppCtx.Provider>;
}

export function useApp() {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error("useApp must be used within AppStateProvider");
  return ctx;
}

/* ------------------------------------------------------------------ */
/*  Helpers                                                           */
/* ------------------------------------------------------------------ */

export const STATUS_LABEL = {
  draft: "Draft",
  awaiting_deposit: "Awaiting Deposit",
  under_review: "Under Review",
  needs_info: "More Information Needed",
  confirmed: "Confirmed",
  cannot_fulfill: "Cannot Fulfill",
};

export const STATUS_TONE = {
  draft: "text-stone-600 bg-stone-100 border-stone-300",
  awaiting_deposit: "text-amber-800 bg-amber-50 border-amber-300",
  under_review: "text-emerald-900 bg-emerald-50 border-emerald-800",
  needs_info: "text-amber-900 bg-amber-50 border-amber-500",
  confirmed: "text-emerald-900 bg-emerald-50 border-emerald-900",
  cannot_fulfill: "text-red-900 bg-red-50 border-red-800",
};

export function nextReference(prefix, list) {
  const existing = list
    .map((x) => (typeof x === "string" ? x : x.id || ""))
    .filter((s) => s.startsWith(prefix))
    .map((s) => parseInt(s.replace(prefix, "").replace(/\D/g, ""), 10) || 0);
  const max = existing.length ? Math.max(...existing) : 10244;
  return `${prefix}${max + 1}`;
}

export function businessDayDueFrom(fromDate) {
  let d = new Date(fromDate);
  let added = 0;
  while (added < 3) {
    d.setDate(d.getDate() + 1);
    const wd = d.getDay();
    if (wd !== 0 && wd !== 6) added += 1;
  }
  return iso(d);
}

export { iso };
