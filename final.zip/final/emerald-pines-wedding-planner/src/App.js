import "@/index.css";
import { BrowserRouter, Routes, Route, Navigate, useLocation } from "react-router-dom";
import { Toaster } from "sonner";
import { AppStateProvider, useApp } from "@/state/store";
import Shell from "@/components/Shell";
import Login from "@/pages/Login";
import Home from "@/pages/Home";
import Availability from "@/pages/Availability";
import PlanForm from "@/pages/PlanForm";
import ReviewPlan from "@/pages/ReviewPlan";
import Deposit from "@/pages/Deposit";
import RequestStatus from "@/pages/RequestStatus";
import Receipt from "@/pages/Receipt";
import Help from "@/pages/Help";
import CoordHome from "@/pages/CoordHome";
import CoordQueue from "@/pages/CoordQueue";
import CoordReview from "@/pages/CoordReview";
import CoordApprove from "@/pages/CoordApprove";
import CoordVenue from "@/pages/CoordVenue";
import CoordRefund from "@/pages/CoordRefund";
import CoordRefundProcessing from "@/pages/CoordRefundProcessing";
import CoordHelp from "@/pages/CoordHelp";
import AdminHome from "@/pages/AdminHome";
import AdminStaff from "@/pages/AdminStaff";
import AdminStaffDetail from "@/pages/AdminStaffDetail";
import AdminHelp from "@/pages/AdminHelp";

function Guarded({ children }) {
  const { state } = useApp();
  const loc = useLocation();
  if (!state.session && loc.pathname !== "/login") {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function App() {
  return (
    <AppStateProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/*"
            element={
              <Guarded>
                <Shell>
                  <Routes>
                    {/* Client */}
                    <Route path="/" element={<Home />} />
                    <Route path="/availability" element={<Availability />} />
                    <Route path="/plan" element={<PlanForm />} />
                    <Route path="/review" element={<ReviewPlan />} />
                    <Route path="/deposit" element={<Deposit />} />
                    <Route path="/status" element={<RequestStatus />} />
                    <Route path="/status/:id" element={<RequestStatus />} />
                    <Route path="/receipt/:id" element={<Receipt />} />
                    <Route path="/help" element={<Help />} />

                    {/* Coordinator */}
                    <Route path="/coord" element={<CoordHome />} />
                    <Route path="/coord/queue" element={<CoordQueue />} />
                    <Route path="/coord/review/:id" element={<CoordReview />} />
                    <Route path="/coord/approve/:id" element={<CoordApprove />} />
                    <Route path="/coord/venue" element={<CoordVenue />} />
                    <Route path="/coord/refund/:id" element={<CoordRefund />} />
                    <Route
                      path="/coord/refund/:id/processing"
                      element={<CoordRefundProcessing />}
                    />
                    <Route path="/coord/help" element={<CoordHelp />} />

                    {/* Administrator */}
                    <Route path="/admin" element={<AdminHome />} />
                    <Route path="/admin/staff" element={<AdminStaff />} />
                    <Route path="/admin/staff/new" element={<AdminStaffDetail />} />
                    <Route path="/admin/staff/:id" element={<AdminStaffDetail />} />
                    <Route path="/admin/help" element={<AdminHelp />} />

                    <Route path="*" element={<Navigate to="/" replace />} />
                  </Routes>
                </Shell>
              </Guarded>
            }
          />
        </Routes>
        <Toaster
          position="top-center"
          toastOptions={{
            style: {
              background: "#fdfbf7",
              color: "#1c1917",
              border: "1px solid #d4af37",
              borderRadius: "2px",
              fontFamily: "Outfit, sans-serif",
            },
          }}
        />
      </BrowserRouter>
    </AppStateProvider>
  );
}

export default App;
