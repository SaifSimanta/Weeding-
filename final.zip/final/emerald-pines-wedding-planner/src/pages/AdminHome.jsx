import React from "react";
import { Link } from "react-router-dom";
import { Users, LifeBuoy } from "lucide-react";

export default function AdminHome() {
  return (
    <div className="max-w-6xl mx-auto px-6 py-12" data-testid="admin-home">
      <div className="section-eyebrow mb-2">Administrator</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-8">Account Management</h1>
      <p className="text-stone-600 max-w-2xl mb-10">
        Manage staff records for coordinators and administrators. All changes
        update local records; no invitations or passwords are sent.
      </p>
      <div className="grid md:grid-cols-2 gap-5 max-w-3xl">
        <Link to="/admin/staff" className="surface-card p-7 hover:border-emerald-900 transition-colors" data-testid="admin-manage-staff">
          <Users className="w-6 h-6 emerald-ink mb-4" strokeWidth={1.4} />
          <div className="font-serif text-2xl mb-1">Manage Staff Accounts</div>
          <p className="text-sm text-stone-500">View, create, edit and deactivate staff records.</p>
        </Link>
        <Link to="/admin/help" className="surface-card p-7 hover:border-emerald-900 transition-colors" data-testid="admin-help-card">
          <LifeBuoy className="w-6 h-6 emerald-ink mb-4" strokeWidth={1.4} />
          <div className="font-serif text-2xl mb-1">Help</div>
          <p className="text-sm text-stone-500">Role descriptions and procedures.</p>
        </Link>
      </div>
    </div>
  );
}
