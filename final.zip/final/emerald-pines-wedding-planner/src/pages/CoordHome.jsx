import React from "react";
import { Link } from "react-router-dom";
import { useApp } from "@/state/store";
import { ClipboardList, CalendarRange, Wallet, LifeBuoy } from "lucide-react";

function Stat({ label, value, tone }) {
  return (
    <div className="surface-card p-6">
      <div className="section-eyebrow mb-2">{label}</div>
      <div className={`font-serif text-4xl ${tone || "emerald-ink"}`}>{value}</div>
    </div>
  );
}

export default function CoordHome() {
  const { state } = useApp();
  const now = new Date();
  const underReview = state.requests.filter((r) => r.status === "under_review").length;
  const needsInfo = state.requests.filter((r) => r.status === "needs_info").length;
  const dueSoon = state.requests.filter((r) => {
    if (!r.reviewDueAt) return false;
    const days = (new Date(r.reviewDueAt) - now) / (1000 * 60 * 60 * 24);
    return days >= 0 && days <= 1 && (r.status === "under_review" || r.status === "needs_info");
  }).length;
  const overdue = state.requests.filter((r) => {
    if (!r.reviewDueAt) return false;
    return new Date(r.reviewDueAt) < now && (r.status === "under_review" || r.status === "needs_info");
  }).length;
  const refundsPending = state.requests.filter((r) => r.refund?.status === "pending").length;

  return (
    <div className="max-w-7xl mx-auto px-6 py-12" data-testid="coord-home">
      <div className="section-eyebrow mb-2">Coordinator</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-10">Operations Dashboard</h1>

      <div className="grid md:grid-cols-5 gap-4 mb-10">
        <Stat label="Under Review" value={underReview} />
        <Stat label="Needs Info" value={needsInfo} tone="text-amber-900" />
        <Stat label="Due Soon" value={dueSoon} tone="text-amber-800" />
        <Stat label="Overdue" value={overdue} tone="text-red-800" />
        <Stat label="Refunds Pending" value={refundsPending} tone="text-red-800" />
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        {[
          { to: "/coord/queue", icon: ClipboardList, label: "Request Queue", desc: "Review and manage inquiries" },
          { to: "/coord/venue", icon: CalendarRange, label: "Venue Availability", desc: "Closures and reservations" },
          { to: "/coord/queue", icon: Wallet, label: "Refund Review", desc: "Process deposit refunds" },
          { to: "/coord/help", icon: LifeBuoy, label: "Coordinator Help", desc: "Guides and policies" },
        ].map((c) => (
          <Link key={c.label} to={c.to} className="surface-card p-6 hover:border-emerald-900 transition-colors" data-testid={`coord-card-${c.label.toLowerCase().replace(/\s+/g, "-")}`}>
            <c.icon className="w-6 h-6 emerald-ink mb-4" strokeWidth={1.4} />
            <div className="font-serif text-xl mb-1">{c.label}</div>
            <div className="text-xs text-stone-500">{c.desc}</div>
          </Link>
        ))}
      </div>
    </div>
  );
}
