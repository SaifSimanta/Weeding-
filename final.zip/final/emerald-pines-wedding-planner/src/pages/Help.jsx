import React, { useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { ChevronDown } from "lucide-react";
import { useApp, businessDayDueFrom, iso } from "@/state/store";

const FAQS = [
  { q: "How long does the review take?", a: "All inquiries are completed within 3 business days of submission." },
  { q: "Is the $100 deposit refundable?", a: "Yes — fully refundable if we cannot provide every facility and service you request." },
  { q: "Does the deposit reserve my date?", a: "No. Your date is reserved only when a coordinator confirms the reservation after review." },
  { q: "Can I revise my plan after submission?", a: "Yes. Revising a paid request does not require a second deposit." },
  { q: "What if I cancel voluntarily?", a: "Please contact a coordinator — voluntary cancellation policy is handled individually." },
];

export default function Help() {
  const { state, dispatch } = useApp();
  const loc = useLocation();
  const nav = useNavigate();

  const [form, setForm] = useState({
    name: "",
    email: "",
    subject: loc.state?.requestRef ? `Re: ${loc.state.requestRef}` : "",
    message: "",
    requestRef: loc.state?.requestRef || null,
  });
  const [errors, setErrors] = useState({});
  const [openIdx, setOpenIdx] = useState(0);

  const send = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Required";
    if (!form.email.trim()) errs.email = "Required";
    if (!form.subject.trim()) errs.subject = "Required";
    if (!form.message.trim()) errs.message = "Required";
    setErrors(errs);
    if (Object.keys(errs).length) return;
    const id = `INQ-${2300 + state.inquiries.length}`;
    dispatch({
      type: "ADD_INQUIRY",
      inquiry: {
        id,
        name: form.name,
        email: form.email,
        subject: form.subject,
        message: form.message,
        createdAt: iso(new Date()),
        status: "open",
        reply: "",
        requestRef: form.requestRef,
      },
    });
    toast.success(`Inquiry sent · Reference ${id}. Response due ${businessDayDueFrom(new Date())}.`);
    setForm({ name: "", email: "", subject: "", message: "", requestRef: null });
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12" data-testid="client-help">
      <button onClick={() => nav(-1)} className="btn-ghost text-sm mb-4" data-testid="back-btn">← Back</button>
      <div className="section-eyebrow mb-2">Help</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-2">How may we help you?</h1>
      <p className="text-stone-600 mb-10 max-w-2xl">
        Planning steps, deposit policy, date changes, and contact — all in one
        place. Every inquiry receives a response within three business days.
      </p>

      <div className="grid md:grid-cols-[1fr_380px] gap-8">
        <div className="space-y-2">
          {FAQS.map((f, i) => (
            <button
              key={i}
              className="w-full text-left surface-card p-5 cursor-pointer"
              onClick={() => setOpenIdx(openIdx === i ? -1 : i)}
              data-testid={`faq-${i}`}
            >
              <div className="flex items-center justify-between">
                <span className="font-medium text-stone-800">{f.q}</span>
                <ChevronDown className={`w-4 h-4 transition-transform ${openIdx === i ? "rotate-180" : ""}`} />
              </div>
              {openIdx === i && (
                <p className="mt-3 text-sm text-stone-600 leading-relaxed">{f.a}</p>
              )}
            </button>
          ))}

          {/* Replies from coordinator */}
          {state.inquiries.filter((i) => i.reply).map((i) => (
            <div key={i.id} className="surface-card p-5" style={{ borderColor: "#D4AF37" }} data-testid={`reply-${i.id}`}>
              <div className="section-eyebrow mb-2">Coordinator Reply · {i.subject}</div>
              <p className="text-sm text-stone-700 whitespace-pre-wrap">{i.reply}</p>
            </div>
          ))}
        </div>

        <aside className="surface-card p-6">
          <div className="section-eyebrow mb-4">Send an Inquiry</div>
          <div className="space-y-3">
            {form.requestRef && (
              <div className="text-xs text-stone-500">Regarding request {form.requestRef}</div>
            )}
            <div>
              <label className="label-field">Your name *</label>
              <input className="input-field" value={form.name} data-testid="inq-name"
                onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
              {errors.name && <p className="text-xs text-red-800">{errors.name}</p>}
            </div>
            <div>
              <label className="label-field">Email *</label>
              <input className="input-field" value={form.email} data-testid="inq-email"
                onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
              {errors.email && <p className="text-xs text-red-800">{errors.email}</p>}
            </div>
            <div>
              <label className="label-field">Subject *</label>
              <input className="input-field" value={form.subject} data-testid="inq-subject"
                onChange={(e) => setForm((f) => ({ ...f, subject: e.target.value }))} />
              {errors.subject && <p className="text-xs text-red-800">{errors.subject}</p>}
            </div>
            <div>
              <label className="label-field">Message *</label>
              <textarea rows={5} className="input-field" value={form.message} data-testid="inq-message"
                onChange={(e) => setForm((f) => ({ ...f, message: e.target.value }))} />
              {errors.message && <p className="text-xs text-red-800">{errors.message}</p>}
            </div>
            <button className="btn-primary w-full justify-center" onClick={send} data-testid="send-inquiry-btn">
              Send Inquiry
            </button>
          </div>
        </aside>
      </div>
    </div>
  );
}
