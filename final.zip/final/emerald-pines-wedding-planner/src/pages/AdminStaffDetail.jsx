import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useApp } from "@/state/store";

export default function AdminStaffDetail() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const isNew = !id;
  const existing = state.staff.find((s) => s.id === id);

  const [form, setForm] = useState(
    existing || { id: `STF-${Date.now()}`, name: "", email: "", role: "Coordinator", active: true }
  );
  const [errors, setErrors] = useState({});
  const [deactivateOpen, setDeactivateOpen] = useState(false);

  const save = () => {
    const errs = {};
    if (!form.name.trim()) errs.name = "Required";
    if (!form.email.trim()) errs.email = "Required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) errs.email = "Invalid email";
    else {
      const dup = state.staff.find((s) => s.email.toLowerCase() === form.email.toLowerCase() && s.id !== form.id);
      if (dup) errs.email = "Another staff record already uses this email";
    }
    setErrors(errs);
    if (Object.keys(errs).length) return;
    dispatch({ type: "UPSERT_STAFF", staff: form });
    toast.success(isNew ? "Staff account created" : "Staff account updated");
    nav("/admin/staff");
  };

  const doDeactivate = () => {
    dispatch({ type: "DEACTIVATE_STAFF", id: form.id });
    toast.success(`${form.name} deactivated`);
    setDeactivateOpen(false);
    nav("/admin/staff");
  };

  return (
    <div className="max-w-2xl mx-auto px-6 py-12" data-testid="admin-staff-detail">
      <button onClick={() => nav("/admin/staff")} className="btn-ghost text-sm mb-4">← Staff Accounts</button>
      <div className="section-eyebrow mb-2">{isNew ? "Create" : "Edit"} Staff Account</div>
      <h1 className="text-4xl font-serif mb-8">{isNew ? "New staff member" : form.name}</h1>

      <div className="surface-card p-8 space-y-4">
        <div>
          <label className="label-field">Full name *</label>
          <input className="input-field" value={form.name} data-testid="staff-name"
            onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} />
          {errors.name && <p className="text-xs text-red-800">{errors.name}</p>}
        </div>
        <div>
          <label className="label-field">Email *</label>
          <input className="input-field" value={form.email} data-testid="staff-email"
            onChange={(e) => setForm((f) => ({ ...f, email: e.target.value }))} />
          {errors.email && <p className="text-xs text-red-800">{errors.email}</p>}
        </div>
        <div>
          <label className="label-field">Role *</label>
          <select className="input-field" value={form.role} data-testid="staff-role"
            onChange={(e) => setForm((f) => ({ ...f, role: e.target.value }))}>
            <option>Coordinator</option>
            <option>Administrator</option>
          </select>
        </div>
        <label className="flex items-center gap-2 cursor-pointer">
          <input type="checkbox" className="accent-emerald-900" checked={form.active}
            onChange={(e) => setForm((f) => ({ ...f, active: e.target.checked }))} data-testid="staff-active" />
          <span className="text-sm">Active</span>
        </label>
      </div>

      <div className="flex justify-between items-center flex-wrap gap-2 mt-6">
        <div className="flex gap-2">
          <button className="btn-ghost border border-stone-300" onClick={() => nav("/admin/staff")} data-testid="staff-cancel">Cancel</button>
          <button className="btn-primary" onClick={save} data-testid="staff-save">Save</button>
        </div>
        {!isNew && form.active && (
          <button className="btn-ghost border border-red-800 text-red-800" onClick={() => setDeactivateOpen(true)} data-testid="staff-deactivate">
            Deactivate
          </button>
        )}
      </div>

      {deactivateOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="deactivate-modal">
          <div className="surface-card p-8 max-w-md w-full">
            <div className="section-eyebrow mb-2 text-red-800">Confirm Deactivation</div>
            <h2 className="font-serif text-2xl mb-3">Deactivate {form.name}?</h2>
            <p className="text-sm text-stone-600 mb-6">
              Marking inactive prevents this fictional account from receiving new assignments.
              Prior review entries will be preserved. The global View-as selector remains available.
            </p>
            <div className="flex justify-end gap-2">
              <button className="btn-ghost border border-stone-300" onClick={() => setDeactivateOpen(false)} data-testid="deactivate-cancel">Cancel</button>
              <button className="btn-danger" onClick={doDeactivate} data-testid="deactivate-confirm">Confirm Deactivation</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
