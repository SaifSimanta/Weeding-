import React from "react";
import { Link } from "react-router-dom";
import { CalendarCheck, FileHeart, Scroll, LifeBuoy, ArrowRight } from "lucide-react";
import { motion } from "framer-motion";

const HERO =
  "https://images.pexels.com/photos/33079800/pexels-photo-33079800.jpeg";

export default function Home() {
  return (
    <div data-testid="client-home">
      {/* Hero */}
      <section className="relative overflow-hidden">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO})` }}
          aria-hidden
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(120deg, rgba(10,61,45,0.88) 0%, rgba(10,61,45,0.55) 55%, rgba(10,61,45,0.3) 100%)",
          }}
          aria-hidden
        />
        <div className="relative max-w-7xl mx-auto px-6 py-24 md:py-36">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="max-w-2xl text-ivory"
            style={{ color: "#FDFBF7" }}
          >
            <div
              className="text-xs tracking-[0.35em] uppercase mb-4"
              style={{ color: "#D4AF37" }}
            >
              Weddings at Emerald Pines
            </div>
            <h1 className="text-5xl md:text-6xl font-serif leading-[1.05] mb-6">
              A legacy begins beneath our pines.
            </h1>
            <p className="text-lg md:text-xl text-stone-100/90 font-light leading-relaxed mb-10">
              Plan your wedding with our coordinators, reserve a date with a
              simple $100 application deposit, and receive a decision within three
              business days.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link to="/plan" className="btn-primary" data-testid="hero-start-plan" style={{ background: "#D4AF37", color: "#0A3D2D" }}>
                Start Wedding Plan
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/availability"
                className="btn-outline"
                data-testid="hero-check-availability"
                style={{ borderColor: "#FDFBF7", color: "#FDFBF7" }}
              >
                Check Availability
              </Link>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Primary actions */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="section-eyebrow mb-2">Your Planning Journey</div>
        <h2 className="text-3xl md:text-4xl font-serif mb-12 max-w-2xl">
          Four steps, carefully attended.
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-5">
          {[
            {
              icon: CalendarCheck,
              title: "Check Availability",
              desc: "Browse open dates and venues on our shared calendar.",
              to: "/availability",
              test: "card-availability",
            },
            {
              icon: FileHeart,
              title: "Start Wedding Plan",
              desc: "Share your vision — guests, cultural rites, services, and venues.",
              to: "/plan",
              test: "card-plan",
            },
            {
              icon: Scroll,
              title: "View My Request",
              desc: "Track your review progress and coordinator messages.",
              to: "/status",
              test: "card-status",
            },
            {
              icon: LifeBuoy,
              title: "Help & Refund Terms",
              desc: "Frequently asked questions, contact, and deposit policy.",
              to: "/help",
              test: "card-help",
            },
          ].map((c) => (
            <Link
              key={c.to}
              to={c.to}
              data-testid={c.test}
              className="group surface-card p-7 hover:border-emerald-900 transition-colors block"
            >
              <c.icon
                className="w-7 h-7 mb-6 text-emerald-900"
                style={{ color: "#0A3D2D" }}
                strokeWidth={1.4}
              />
              <h3 className="text-2xl font-serif mb-2">{c.title}</h3>
              <p className="text-sm text-stone-600 leading-relaxed">{c.desc}</p>
              <div
                className="mt-6 text-xs tracking-[0.2em] uppercase flex items-center gap-1 group-hover:gap-2 transition-all"
                style={{ color: "#A37C17" }}
              >
                Continue <ArrowRight className="w-3.5 h-3.5" />
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Policy strip */}
      <section className="border-y border-stone-200 bg-stone-50/60">
        <div className="max-w-7xl mx-auto px-6 py-12 grid md:grid-cols-3 gap-8">
          {[
            {
              k: "3 Business Days",
              v: "Every wedding inquiry receives a coordinator response within three business days.",
            },
            {
              k: "$100 Deposit",
              v: "A small application deposit accompanies every plan submitted for review.",
            },
            {
              k: "Fully Refundable",
              v: "If we cannot fulfil every facility and service you request, we refund your deposit in full.",
            },
          ].map((p) => (
            <div key={p.k}>
              <div
                className="text-xs tracking-[0.3em] uppercase mb-2"
                style={{ color: "#A37C17" }}
              >
                {p.k}
              </div>
              <p className="text-stone-700 leading-relaxed">{p.v}</p>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}
