import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useApp, VENUES, iso } from "@/state/store";

export default function CoordVenue() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState({ date: "", reason: "", venueId: "" });

  const confirmedBookings = state.requests.filter((r) => r.status === "confirmed");

  const openAdd = () => { setEditing("new"); setForm({ date: "", reason: "", venueId: "" }); };
  const openEdit = (c) => { setEditing(c.id); setForm({ date: c.date, reason: c.reason, venueId: c.venueId || "" }); };

  const save = () => {
    if (!form.date || !form.reason) { toast.error("Date and reason required"); return; }
    const conflict = confirmedBookings.find((r) => r.weddingDate === form.date && (!form.venueId || r.venueId === form.venueId));
    if (conflict) {
      toast.error(`Conflict with confirmed booking for ${conflict.client.name}`);
      return;
    }
    if (editing === "new") {
      const closure = { id: `CLO-${Date.now()}`, date: form.date, reason: form.reason, venueId: form.venueId || null, system: false };
      dispatch({ type: "ADD_CLOSURE", closure });
      toast.success("Closure added");
    } else {
      const existing = state.closures.find((c) => c.id === editing);
      dispatch({ type: "UPDATE_CLOSURE", closure: { ...existing, ...form, venueId: form.venueId || null } });
      toast.success("Closure updated");
    }
    setEditing(null);
  };

  const remove = (c) => {
    if (c.system) { toast.error("System closures (confirmed bookings) cannot be removed from here"); return; }
    if (!window.confirm(`Remove closure on ${c.date}?`)) return;
    dispatch({ type: "REMOVE_CLOSURE", id: c.id });
    toast.success("Closure removed");
  };

  const all = [
    ...state.closures.map((c) => ({ ...c, kind: c.system ? "Reserved" : "Closure" })),
    ...confirmedBookings.map((r) => ({
      id: `RES-${r.id}`, date: r.weddingDate,
      reason: `Confirmed reservation · ${r.client.name}`,
      venueId: r.venueId, system: true, kind: "Reservation",
    })),
  ].sort((a, b) => a.date.localeCompare(b.date));

  return (
    <div className="max-w-6xl mx-auto px-6 py-12" data-testid="coord-venue">
      <div className="flex justify-between flex-wrap items-start gap-4 mb-10">
        <div>
          <div className="section-eyebrow mb-2">Coordinator</div>
          <h1 className="text-4xl font-serif">Venue Availability</h1>
        </div>
        <button className="btn-primary" onClick={openAdd} data-testid="add-closure-btn">Add Closure</button>
      </div>

      <div className="surface-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-stone-50 text-xs uppercase tracking-widest text-stone-500">
            <tr>
              <th className="text-left px-4 py-3">Date</th>
              <th className="text-left px-4 py-3">Venue</th>
              <th className="text-left px-4 py-3">Reason</th>
              <th className="text-left px-4 py-3">Kind</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {all.map((c) => (
              <tr key={c.id} className="border-t border-stone-200">
                <td className="px-4 py-3">{c.date}</td>
                <td className="px-4 py-3">{c.venueId ? VENUES.find((v) => v.id === c.venueId)?.name : "All venues"}</td>
                <td className="px-4 py-3 text-stone-700">{c.reason}</td>
                <td className="px-4 py-3"><span className="pill text-emerald-900 border-emerald-900">{c.kind}</span></td>
                <td className="px-4 py-3 text-right space-x-2">
                  {!c.system && (
                    <>
                      <button className="btn-ghost text-sm border border-stone-300" onClick={() => openEdit(c)} data-testid={`edit-${c.id}`}>Edit</button>
                      <button className="btn-ghost text-sm border border-red-800 text-red-800" onClick={() => remove(c)} data-testid={`remove-${c.id}`}>Remove</button>
                    </>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <button onClick={() => nav(-1)} className="btn-ghost text-sm mt-6 border border-stone-300">Return</button>

      {editing && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="closure-modal">
          <div className="surface-card p-8 max-w-md w-full">
            <div className="section-eyebrow mb-2">{editing === "new" ? "Add" : "Edit"} Closure</div>
            <h2 className="font-serif text-2xl mb-4">Mark date unavailable</h2>
            <div className="space-y-3">
              <div>
                <label className="label-field">Date *</label>
                <input type="date" className="input-field" value={form.date}
                  onChange={(e) => setForm((f) => ({ ...f, date: e.target.value }))} data-testid="closure-date" />
              </div>
              <div>
                <label className="label-field">Venue</label>
                <select className="input-field" value={form.venueId}
                  onChange={(e) => setForm((f) => ({ ...f, venueId: e.target.value }))} data-testid="closure-venue">
                  <option value="">All venues</option>
                  {VENUES.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
                </select>
              </div>
              <div>
                <label className="label-field">Reason *</label>
                <input className="input-field" value={form.reason}
                  onChange={(e) => setForm((f) => ({ ...f, reason: e.target.value }))} data-testid="closure-reason" />
              </div>
            </div>
            <div className="flex justify-end gap-2 mt-6">
              <button className="btn-ghost border border-stone-300" onClick={() => setEditing(null)} data-testid="closure-cancel">Cancel</button>
              <button className="btn-primary" onClick={save} data-testid="closure-save">Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
