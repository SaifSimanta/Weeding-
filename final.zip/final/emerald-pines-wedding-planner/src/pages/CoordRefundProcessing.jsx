import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useApp } from "@/state/store";

export default function CoordRefundProcessing() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const req = state.requests.find((r) => r.id === id);
  const [status, setStatus] = useState("processing");

  useEffect(() => {
    const outcome = state.presentation.refundOutcome;
    const t = setTimeout(() => setStatus(outcome), 1200);
    return () => clearTimeout(t);
  }, [state.presentation.refundOutcome]);

  useEffect(() => {
    if (!req || status === "processing") return;
    if (status !== req.refund?.status) {
      dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
        refund: { ...req.refund, status },
      }});
      if (status === "completed")
        dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Refund completed" });
    }
  }, [status]); // eslint-disable-line

  if (!req) return <div className="p-12 text-center">Request not found</div>;

  const complete = () => {
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
      refund: { ...req.refund, status: "completed" },
    }});
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Refund completed" });
    setStatus("completed");
    toast.success("Refund marked completed");
  };

  const retry = () => {
    setStatus("processing");
    setTimeout(() => setStatus("completed"), 900);
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: { refund: { ...req.refund, status: "completed" } } });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Refund completed (retry)" });
    toast.success("Refund retry succeeded");
  };

  const check = () => {
    setStatus("completed");
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: { refund: { ...req.refund, status: "completed" } } });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Refund resolved via status check" });
    toast.success("Refund resolved — no duplicate record created");
  };

  return (
    <div className="max-w-3xl mx-auto px-6 py-16 text-center" data-testid="refund-processing">
      <div className="section-eyebrow mb-2">{req.reference}</div>
      <h1 className="text-4xl font-serif mb-8">Refund Processing</h1>

      <div className="surface-card p-10" style={{ borderColor: "#D4AF37" }}>
        <div className="mb-6">
          <div className="text-xs tracking-[0.25em] uppercase text-stone-500 mb-2">Status</div>
          <div className={`font-serif text-5xl capitalize ${
            status === "completed" ? "emerald-ink" :
            status === "failed" ? "text-red-800" : "text-amber-800"
          }`} data-testid="refund-result-status">
            {status === "processing" ? "Processing…" : status}
          </div>
        </div>
        <div className="divider-gold mb-6" />
        <div className="text-sm text-stone-700 grid sm:grid-cols-2 gap-3">
          <div>Amount · ${req.refund?.amount}</div>
          <div>Reference · {req.refund?.reference}</div>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mt-6">
        {status === "pending" && (
          <button className="btn-primary" onClick={complete} data-testid="complete-refund-btn">Complete Refund</button>
        )}
        {status === "failed" && (
          <button className="btn-primary" onClick={retry} data-testid="retry-refund-btn">Retry</button>
        )}
        {status === "unknown" && (
          <button className="btn-primary" onClick={check} data-testid="check-refund-btn">Check Refund Status</button>
        )}
        <button className="btn-outline" onClick={() => nav("/coord/queue")} data-testid="return-queue-btn">Return to Queue</button>
        <button className="btn-ghost border border-stone-300" onClick={() => nav(`/coord/refund/${req.id}`)}>Back to Refund Review</button>
      </div>
    </div>
  );
}
