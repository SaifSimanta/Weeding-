import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown } from "lucide-react";

const TOPICS = [
  { q: "Reviewing a facility request", a: "Mark each item fulfillable, need clarification, or cannot fulfill. Save your findings before continuing." },
  { q: "Requesting more information", a: "Use 'Ask for Details' and the client will see your message in their Request Status." },
  { q: "Confirming a plan", a: "All requirements must be marked fulfillable, the client must agree, and a final date check must pass." },
  { q: "Handling date conflicts", a: "The system blocks confirmation; offer the client alternate dates or return to review." },
  { q: "Refunding an unfulfillable request", a: "Open Cannot Fulfill & Refund Review and issue the full $100 refund. Any existing reservation is cancelled." },
];

export default function CoordHelp() {
  const nav = useNavigate();
  const [open, setOpen] = useState(0);
  return (
    <div className="max-w-4xl mx-auto px-6 py-12" data-testid="coord-help">
      <button onClick={() => nav(-1)} className="btn-ghost text-sm mb-4">← Back</button>
      <div className="section-eyebrow mb-2">Coordinator</div>
      <h1 className="text-4xl font-serif mb-8">Help &amp; Procedures</h1>
      <div className="space-y-2">
        {TOPICS.map((t, i) => (
          <button key={i} onClick={() => setOpen(open === i ? -1 : i)} className="w-full text-left surface-card p-5" data-testid={`coord-help-${i}`}>
            <div className="flex justify-between items-center">
              <span className="font-medium">{t.q}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${open === i ? "rotate-180" : ""}`} />
            </div>
            {open === i && <p className="mt-3 text-sm text-stone-600">{t.a}</p>}
          </button>
        ))}
      </div>
      <button className="btn-outline mt-6" onClick={() => nav("/coord")}>Home</button>
    </div>
  );
}
