import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Lock } from "lucide-react";
import { toast } from "sonner";
import { useApp, VENUES, businessDayDueFrom, iso } from "@/state/store";

export default function Deposit() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const req = state.requests.find((r) => r.id === state.activeRequestId);
  const [agree, setAgree] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [lastOutcome, setLastOutcome] = useState(null);
  const [attemptId, setAttemptId] = useState(null);

  if (!req) return (
    <div className="max-w-3xl mx-auto px-6 py-24 text-center">
      <h2 className="font-serif text-3xl">No plan to deposit</h2>
    </div>
  );

  const venue = VENUES.find((v) => v.id === req.venueId);

  const doPay = () => {
    if (!agree) {
      toast.error("Please acknowledge the deposit and refund terms.");
      return;
    }
    if (processing) return;
    if (!attemptId) setAttemptId(`ATT-${Date.now()}`);
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      const outcome = state.presentation.paymentOutcome;
      setLastOutcome(outcome);
      if (outcome === "success") finalize();
    }, 1100);
  };

  const finalize = () => {
    // Idempotent — don't create duplicate records
    if (req.deposit?.paid) {
      nav(`/receipt/${req.id}`);
      return;
    }
    const today = iso(new Date());
    const due = businessDayDueFrom(new Date());
    const reference = `PMT-${77200 + state.requests.length}`;
    dispatch({
      type: "PATCH_REQUEST",
      id: req.id,
      patch: {
        status: "under_review",
        submittedAt: today,
        reviewDueAt: due,
        deposit: { paid: true, amount: 100, reference, date: today },
      },
    });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Plan submitted" });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Deposit received" });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Under review" });
    toast.success("Deposit received. Request now under review.");
    nav(`/receipt/${req.id}`);
  };

  const checkStatus = () => {
    // Resolve unknown — reuse same attempt. Here we always resolve to success.
    toast.success("Payment confirmed on bank — resolving same attempt");
    setLastOutcome("success");
    finalize();
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12" data-testid="deposit-page">
      <button onClick={() => nav("/review")} className="btn-ghost text-sm mb-4" data-testid="back-btn">
        <ArrowLeft className="w-4 h-4 inline mr-1" /> Back
      </button>
      <div className="section-eyebrow mb-2">Application Deposit</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-2">Submit your plan for review</h1>
      <p className="text-stone-600 mb-10 max-w-2xl">
        A $100 application deposit accompanies your plan. It is fully refundable
        if we cannot fulfil every facility and service you request.
      </p>

      <div className="grid md:grid-cols-[1fr_320px] gap-8">
        <div className="surface-card p-8 space-y-6">
          <section>
            <div className="section-eyebrow mb-2">Plan Summary</div>
            <div className="text-sm space-y-1">
              <div><span className="text-stone-500">Couple: </span>{req.client.name}</div>
              <div><span className="text-stone-500">Venue: </span>{venue?.name}</div>
              <div><span className="text-stone-500">Date: </span>{req.weddingDate}</div>
              <div><span className="text-stone-500">Guests: </span>{req.guestCount}</div>
            </div>
          </section>
          <div className="divider-gold" />
          <section>
            <div className="section-eyebrow mb-2">Refund Policy</div>
            <p className="text-sm text-stone-700 leading-relaxed">
              The club fully refunds the $100 deposit if it cannot provide every
              facility and service you have requested. For voluntary customer
              cancellation, please speak with a coordinator. Revisions to the same
              paid request do not require a second deposit.
            </p>
          </section>
          <div className="divider-gold" />
          <label className="flex items-start gap-2 cursor-pointer text-sm" data-testid="agree-terms">
            <input type="checkbox" className="mt-1 accent-emerald-900"
              checked={agree} onChange={(e) => setAgree(e.target.checked)} />
            <span>I understand the $100 application deposit and the refund policy above.</span>
          </label>

          <div className="surface-ivory border border-stone-200 p-4 rounded-sm text-xs text-stone-500 flex items-center gap-2">
            <Lock className="w-3.5 h-3.5" />
            Presentation only. No real payment is processed.
          </div>
        </div>

        <div className="space-y-4">
          <div className="surface-card p-5">
            <div className="flex justify-between items-baseline mb-4">
              <div className="text-stone-600 text-sm">Application deposit</div>
              <div className="font-serif text-3xl emerald-ink">$100</div>
            </div>
            <button
              className="btn-primary w-full justify-center"
              disabled={processing || lastOutcome === "success"}
              onClick={doPay}
              data-testid="pay-deposit-btn"
            >
              {processing ? "Processing…" : "Pay $100 and Submit Request"}
            </button>

            {lastOutcome === "declined" && (
              <div className="mt-4 text-sm text-red-800 border border-red-300 bg-red-50 p-3 rounded-sm" data-testid="payment-declined">
                Payment was declined. Please try again — your details are preserved.
                <button onClick={doPay} className="block mt-2 underline" data-testid="try-again-btn">
                  Try Again
                </button>
              </div>
            )}

            {lastOutcome === "unknown" && (
              <div className="mt-4 text-sm text-amber-900 border border-amber-400 bg-amber-50 p-3 rounded-sm" data-testid="payment-unknown">
                Payment status unknown. We&apos;ll resolve this attempt without creating a duplicate.
                <button onClick={checkStatus} className="block mt-2 underline" data-testid="check-status-btn">
                  Check Payment Status
                </button>
              </div>
            )}
          </div>

          <button className="btn-ghost border border-stone-300 w-full justify-center" onClick={() => nav("/")} data-testid="cancel-btn">
            Cancel (keep draft)
          </button>
        </div>
      </div>
    </div>
  );
}
