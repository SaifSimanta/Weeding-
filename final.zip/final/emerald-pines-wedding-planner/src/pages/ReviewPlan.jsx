import React from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useApp, VENUES } from "@/state/store";
import { toast } from "sonner";

function Field({ label, value }) {
  return (
    <div>
      <div className="label-field">{label}</div>
      <div className="text-stone-800 text-sm">{value || "—"}</div>
    </div>
  );
}

export default function ReviewPlan() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const req = state.requests.find((r) => r.id === state.activeRequestId);

  if (!req) {
    return (
      <div className="max-w-3xl mx-auto px-6 py-24 text-center">
        <h2 className="font-serif text-3xl mb-3">No plan to review</h2>
        <button onClick={() => nav("/plan")} className="btn-primary">Start a plan</button>
      </div>
    );
  }

  const venue = VENUES.find((v) => v.id === req.venueId);
  const hasDeposit = req.deposit?.paid;

  const saveRevision = () => {
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
      status: "under_review",
      coordinatorMessage: "",
    }});
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Revision submitted" });
    toast.success("Revision saved. Returned to Under Review.");
    nav("/status");
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12" data-testid="review-plan">
      <button onClick={() => nav("/plan")} className="btn-ghost text-sm mb-4" data-testid="back-btn">
        <ArrowLeft className="w-4 h-4 inline mr-1" /> Back
      </button>
      <div className="section-eyebrow mb-2">Review</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-2">Wedding Plan Summary</h1>
      <p className="text-stone-600 mb-10">
        Please review the details below before continuing.
      </p>

      <div className="surface-card p-8 space-y-8" style={{ borderColor: "#D4AF37" }}>
        <section>
          <div className="section-eyebrow mb-3">Contact</div>
          <div className="grid md:grid-cols-2 gap-5">
            <Field label="Full name" value={req.client.name} />
            <Field label="Phone" value={req.client.phone} />
            <Field label="Email" value={req.client.email} />
            <Field label="Address" value={req.client.address} />
          </div>
        </section>
        <div className="divider-gold" />
        <section>
          <div className="section-eyebrow mb-3">Venue &amp; Date</div>
          <div className="grid md:grid-cols-3 gap-5">
            <Field label="Venue" value={venue?.name} />
            <Field label="Date" value={req.weddingDate} />
            <Field label="Guest count" value={req.guestCount} />
          </div>
        </section>
        <div className="divider-gold" />
        <section>
          <div className="section-eyebrow mb-3">Special Arrangements</div>
          <div className="space-y-3 text-sm">
            <div>
              <span className="font-medium">Cultural arrangements: </span>
              {req.cultural.enabled ? req.cultural.details : "Not requested"}
            </div>
            <div>
              <span className="font-medium">Silent disco: </span>
              {req.silentDisco.enabled ? req.silentDisco.details : "Not requested"}
            </div>
          </div>
        </section>
        <div className="divider-gold" />
        <section>
          <div className="section-eyebrow mb-3">Facilities &amp; Services</div>
          <div className="space-y-3 text-sm">
            <Field label="Other facilities" value={req.otherFacilities} />
            <Field label="Service notes" value={req.services} />
          </div>
        </section>

        <div className="surface-ivory p-5 border border-stone-200 rounded-sm">
          <div className="section-eyebrow mb-1">Deposit &amp; Refund Policy</div>
          <p className="text-sm text-stone-700">
            A $100 application deposit is collected when you submit for review.
            Payment alone does not reserve the date. We refund your deposit in
            full if we cannot provide every requested facility and service.
          </p>
        </div>
      </div>

      <div className="flex flex-wrap justify-between items-center gap-3 mt-6">
        <div className="flex gap-2 flex-wrap">
          <button className="btn-outline" onClick={() => nav("/plan", { state: { editing: true } })} data-testid="edit-details-btn">
            Edit Details
          </button>
          <button className="btn-ghost border border-stone-300" onClick={() => nav("/")} data-testid="cancel-btn">
            Cancel
          </button>
        </div>
        {hasDeposit ? (
          <button className="btn-primary" onClick={saveRevision} data-testid="save-revision-btn">
            Save Revision
          </button>
        ) : (
          <button className="btn-primary" onClick={() => nav("/deposit")} data-testid="continue-deposit-btn">
            Continue to Deposit
          </button>
        )}
      </div>
    </div>
  );
}
