import React, { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { useApp, VENUES, STATUS_LABEL } from "@/state/store";
import StatusBadge from "@/components/StatusBadge";

export default function CoordQueue() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const [tab, setTab] = useState("requests");
  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const submitted = useMemo(() =>
    state.requests.filter((r) => r.status !== "draft"), [state.requests]);

  const filtered = submitted.filter((r) => {
    const t = q.toLowerCase();
    if (q && !(
      r.client.name.toLowerCase().includes(t) ||
      r.reference.toLowerCase().includes(t) ||
      r.weddingDate.includes(t)
    )) return false;
    if (statusFilter !== "all" && r.status !== statusFilter) return false;
    return true;
  });

  const [replyMap, setReplyMap] = useState({});

  const sendReply = (inq) => {
    const reply = replyMap[inq.id]?.trim();
    if (!reply) { toast.error("Enter a reply first"); return; }
    dispatch({ type: "PATCH_INQUIRY", id: inq.id, patch: { reply, status: "answered" } });
    toast.success("Reply sent and inquiry marked answered");
    setReplyMap((m) => ({ ...m, [inq.id]: "" }));
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12" data-testid="coord-queue">
      <div className="section-eyebrow mb-2">Coordinator</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-6">Request Queue</h1>

      <div className="flex gap-1 mb-6 border-b border-stone-200">
        {[
          { id: "requests", label: "Wedding Requests" },
          { id: "inquiries", label: `Inquiries (${state.inquiries.length})` },
        ].map((t) => (
          <button key={t.id} data-testid={`tab-${t.id}`}
            onClick={() => setTab(t.id)}
            className={`px-4 py-2 text-sm border-b-2 transition-colors ${tab === t.id ? "border-emerald-900 emerald-ink font-medium" : "border-transparent text-stone-500"}`}
            style={tab === t.id ? { borderColor: "#0A3D2D", color: "#0A3D2D" } : {}}
          >{t.label}</button>
        ))}
      </div>

      {tab === "requests" && (
        <>
          <div className="flex gap-3 mb-6 flex-wrap">
            <input className="input-field max-w-sm" placeholder="Search client, date, reference…"
              value={q} onChange={(e) => setQ(e.target.value)} data-testid="queue-search" />
            <select className="input-field max-w-xs" value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)} data-testid="queue-status-filter">
              <option value="all">All statuses</option>
              {Object.entries(STATUS_LABEL).filter(([k]) => k !== "draft").map(([k, v]) => (
                <option key={k} value={k}>{v}</option>
              ))}
            </select>
          </div>

          <div className="surface-card overflow-hidden">
            <table className="w-full text-sm">
              <thead className="bg-stone-50 text-xs uppercase tracking-widest text-stone-500">
                <tr>
                  <th className="text-left px-4 py-3">Reference</th>
                  <th className="text-left px-4 py-3">Client</th>
                  <th className="text-left px-4 py-3">Venue</th>
                  <th className="text-left px-4 py-3">Date</th>
                  <th className="text-left px-4 py-3">Status</th>
                  <th className="text-left px-4 py-3">Due</th>
                  <th />
                </tr>
              </thead>
              <tbody>
                {filtered.map((r) => (
                  <tr key={r.id} className="border-t border-stone-200 hover:bg-stone-50" data-testid={`row-${r.id}`}>
                    <td className="px-4 py-3 font-mono text-xs">{r.reference}</td>
                    <td className="px-4 py-3">{r.client.name}</td>
                    <td className="px-4 py-3">{VENUES.find((v) => v.id === r.venueId)?.name}</td>
                    <td className="px-4 py-3">{r.weddingDate}</td>
                    <td className="px-4 py-3"><StatusBadge status={r.status} /></td>
                    <td className="px-4 py-3 text-stone-600">{r.reviewDueAt || "—"}</td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => {
                        dispatch({ type: "SET_ACTIVE_REQUEST", id: r.id });
                        nav(`/coord/review/${r.id}`);
                      }} className="btn-ghost text-sm border border-stone-300" data-testid={`open-${r.id}`}>Open</button>
                    </td>
                  </tr>
                ))}
                {filtered.length === 0 && (
                  <tr><td colSpan={7} className="text-center py-10 text-stone-400">No requests match your filters.</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </>
      )}

      {tab === "inquiries" && (
        <div className="space-y-4">
          {state.inquiries.length === 0 && <p className="text-stone-500">No inquiries yet.</p>}
          {state.inquiries.map((i) => (
            <div key={i.id} className="surface-card p-5" data-testid={`inq-${i.id}`}>
              <div className="flex justify-between gap-4 flex-wrap mb-2">
                <div>
                  <div className="font-medium">{i.subject}</div>
                  <div className="text-xs text-stone-500">{i.name} · {i.email} · {i.createdAt}</div>
                </div>
                <span className={`pill ${i.status === "answered" ? "text-emerald-900 border-emerald-900" : "text-amber-900 border-amber-500"}`}>
                  {i.status}
                </span>
              </div>
              <p className="text-sm text-stone-700 mb-3">{i.message}</p>
              {i.reply ? (
                <div className="surface-ivory border border-stone-200 p-3 rounded-sm text-sm text-stone-700">
                  <div className="text-xs text-stone-500 mb-1">Your reply</div>
                  {i.reply}
                </div>
              ) : (
                <div className="flex gap-2">
                  <textarea rows={2} className="input-field" placeholder="Type a reply…"
                    value={replyMap[i.id] || ""}
                    onChange={(e) => setReplyMap((m) => ({ ...m, [i.id]: e.target.value }))}
                    data-testid={`reply-field-${i.id}`} />
                  <button onClick={() => sendReply(i)} className="btn-primary" data-testid={`reply-send-${i.id}`}>Send &amp; Mark Answered</button>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
