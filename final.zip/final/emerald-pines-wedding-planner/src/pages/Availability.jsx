import React, { useMemo, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { ChevronLeft, ChevronRight, ArrowLeft } from "lucide-react";
import { toast } from "sonner";
import { useApp, VENUES, iso } from "@/state/store";

const MONTH_NAMES = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December",
];

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}
function firstWeekday(year, month) {
  return new Date(year, month, 1).getDay();
}

export default function Availability() {
  const { state } = useApp();
  const navigate = useNavigate();
  const loc = useLocation();
  const [cursor, setCursor] = useState({ year: 2026, month: 5 }); // June 2026
  const [venueId, setVenueId] = useState("all");
  const [selected, setSelected] = useState(null);

  const unavailableSet = useMemo(() => {
    const s = new Set();
    state.closures.forEach((c) => {
      if (venueId === "all" || !c.venueId || c.venueId === venueId) s.add(c.date);
    });
    state.requests.forEach((r) => {
      if (r.status === "confirmed" && r.weddingDate) {
        if (venueId === "all" || r.venueId === venueId) s.add(r.weddingDate);
      }
    });
    return s;
  }, [state.closures, state.requests, venueId]);

  const reasonMap = useMemo(() => {
    const m = {};
    state.closures.forEach((c) => {
      m[c.date] = c.reason;
    });
    state.requests.forEach((r) => {
      if (r.status === "confirmed")
        m[r.weddingDate] = `Reserved — ${r.client.name.split("&")[0].trim()}`;
    });
    return m;
  }, [state.closures, state.requests]);

  const total = daysInMonth(cursor.year, cursor.month);
  const offset = firstWeekday(cursor.year, cursor.month);
  const cells = [];
  for (let i = 0; i < offset; i++) cells.push(null);
  for (let d = 1; d <= total; d++) {
    cells.push(new Date(cursor.year, cursor.month, d));
  }

  const changeMonth = (delta) => {
    let m = cursor.month + delta;
    let y = cursor.year;
    if (m < 0) { m = 11; y -= 1; }
    if (m > 11) { m = 0; y += 1; }
    setCursor({ year: y, month: m });
  };

  const onSelect = (date) => {
    const s = iso(date);
    if (unavailableSet.has(s)) {
      toast.error("That date is unavailable. Please choose another.");
      return;
    }
    setSelected(s);
  };

  const useDate = () => {
    if (!selected) return;
    const chosenVenue =
      venueId !== "all" ? venueId : VENUES[0].id;
    navigate("/plan", {
      state: { venueId: chosenVenue, weddingDate: selected, preserve: loc.state },
    });
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-12" data-testid="availability-page">
      <button
        onClick={() => navigate(-1)}
        className="btn-ghost text-sm mb-4"
        data-testid="back-btn"
      >
        <ArrowLeft className="w-4 h-4 inline mr-1" />
        Back
      </button>
      <div className="section-eyebrow mb-2">Calendar</div>
      <h1 className="text-4xl md:text-5xl font-serif mb-2">Available Dates</h1>
      <p className="text-stone-600 mb-10 max-w-2xl">
        Select a venue and month to view open dates. Confirmed reservations and
        closures are marked unavailable. A $100 application deposit does not make
        a date unavailable on its own.
      </p>

      <div className="grid lg:grid-cols-[1fr_320px] gap-10">
        <div className="surface-card p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <button
                onClick={() => changeMonth(-1)}
                className="p-2 border border-stone-200 rounded-sm hover:bg-stone-50"
                data-testid="prev-month"
                aria-label="Previous month"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <div className="font-serif text-2xl">
                {MONTH_NAMES[cursor.month]} {cursor.year}
              </div>
              <button
                onClick={() => changeMonth(1)}
                className="p-2 border border-stone-200 rounded-sm hover:bg-stone-50"
                data-testid="next-month"
                aria-label="Next month"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
            </div>
            <select
              value={venueId}
              onChange={(e) => setVenueId(e.target.value)}
              className="input-field max-w-[220px]"
              data-testid="venue-filter"
            >
              <option value="all">All venues</option>
              {VENUES.map((v) => (
                <option key={v.id} value={v.id}>{v.name}</option>
              ))}
            </select>
          </div>

          <div className="grid grid-cols-7 gap-1 text-[11px] tracking-[0.15em] uppercase text-stone-500 mb-2">
            {["Sun","Mon","Tue","Wed","Thu","Fri","Sat"].map((d) => (
              <div key={d} className="text-center py-2">{d}</div>
            ))}
          </div>
          <div className="grid grid-cols-7 gap-1">
            {cells.map((c, i) => {
              if (!c) return <div key={i} className="aspect-square" />;
              const s = iso(c);
              const isUn = unavailableSet.has(s);
              const isSel = selected === s;
              return (
                <button
                  key={i}
                  onClick={() => onSelect(c)}
                  data-testid={`day-${s}`}
                  disabled={isUn}
                  className={`aspect-square rounded-sm flex flex-col items-center justify-center text-sm transition-all relative ${
                    isUn
                      ? "bg-stone-100 text-stone-400 cursor-not-allowed line-through"
                      : isSel
                        ? "border border-amber-500 bg-amber-50 font-medium"
                        : "border border-stone-200 hover:border-emerald-900 hover:bg-emerald-50"
                  }`}
                  title={isUn ? reasonMap[s] || "Unavailable" : "Available"}
                >
                  <span className={isSel ? "emerald-ink font-semibold" : ""}>
                    {c.getDate()}
                  </span>
                  {!isUn && (
                    <span className="text-[9px] tracking-widest uppercase text-emerald-900/70 mt-0.5">
                      Open
                    </span>
                  )}
                </button>
              );
            })}
          </div>
          <div className="flex items-center gap-4 mt-6 text-xs text-stone-500">
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-sm border border-emerald-900" /> Available
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-sm bg-stone-100" /> Unavailable
            </span>
            <span className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-sm border border-amber-500 bg-amber-50" /> Selected
            </span>
          </div>
        </div>

        <div className="space-y-4">
          <div className="surface-card p-5">
            <div className="section-eyebrow mb-2">Selected Date</div>
            <div className="font-serif text-2xl" data-testid="selected-date">
              {selected || "— None —"}
            </div>
            {selected && (
              <div className="text-sm text-stone-600 mt-1">
                {new Date(selected).toLocaleDateString("en-US", {
                  weekday: "long", month: "long", day: "numeric", year: "numeric"
                })}
              </div>
            )}
            <button
              disabled={!selected}
              onClick={useDate}
              className="btn-primary w-full justify-center mt-5"
              data-testid="use-date-btn"
            >
              Use Selected Date
            </button>
            {!selected && (
              <p className="text-xs text-stone-500 mt-3">
                Select an available date above to continue to the wedding plan form.
              </p>
            )}
          </div>

          <div className="surface-card p-5">
            <div className="section-eyebrow mb-3">Venues</div>
            <ul className="space-y-3">
              {VENUES.map((v) => (
                <li key={v.id}>
                  <div className="font-medium text-stone-800 text-sm">{v.name}</div>
                  <div className="text-xs text-stone-500">
                    {v.kind} · up to {v.capacity} guests
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
}
