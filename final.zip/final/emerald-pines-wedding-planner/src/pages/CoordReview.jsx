import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useApp, VENUES } from "@/state/store";
import StatusBadge from "@/components/StatusBadge";

function requirementItems(req) {
  const items = [];
  items.push({ key: "venue", label: `${VENUES.find(v => v.id === req.venueId)?.name} for ${req.guestCount} guests` });
  if (req.cultural.enabled) items.push({ key: "cultural", label: `Cultural: ${req.cultural.details}` });
  if (req.silentDisco.enabled) items.push({ key: "disco", label: `Silent disco: ${req.silentDisco.details}` });
  if (req.otherFacilities) items.push({ key: "facilities", label: `Facilities: ${req.otherFacilities}` });
  if (req.services) items.push({ key: "services", label: `Services: ${req.services}` });
  return items;
}

export default function CoordReview() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const req = state.requests.find((r) => r.id === id);

  const items = req ? requirementItems(req) : [];
  const [findings, setFindings] = useState(() => {
    const existing = req?.findings || [];
    return items.map((it) => {
      const f = existing.find((x) => x.item === it.label);
      return f ? { ...f } : { item: it.label, fulfillable: "yes", notes: "" };
    });
  });
  const [askOpen, setAskOpen] = useState(false);
  const [askText, setAskText] = useState("");
  const [cantOpen, setCantOpen] = useState(false);
  const [cantReason, setCantReason] = useState("");

  if (!req) return <div className="p-12 text-center">Request not found</div>;

  const updateF = (i, patch) => setFindings((arr) => arr.map((f, idx) => idx === i ? { ...f, ...patch } : f));
  const allFulfillable = findings.every((f) => f.fulfillable === "yes");
  const unmetIdx = findings.findIndex((f) => f.fulfillable === "no");

  const saveFindings = () => {
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: { findings } });
    toast.success("Findings saved locally");
  };

  const sendAsk = () => {
    if (!askText.trim()) { toast.error("Enter a message"); return; }
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
      status: "needs_info", coordinatorMessage: askText, findings,
    }});
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "More information requested" });
    toast.success("Message sent — client notified in Request Status");
    setAskOpen(false);
    nav("/coord/queue");
  };

  const submitCant = () => {
    if (unmetIdx < 0) { toast.error("Mark at least one requirement as 'Cannot fulfill'"); return; }
    if (!cantReason.trim()) { toast.error("Enter a reason"); return; }
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
      status: "cannot_fulfill",
      coordinatorMessage: cantReason,
      findings,
      refund: req.deposit?.paid ? {
        amount: 100, reference: `RFD-${33100 + state.requests.length}`,
        status: "pending", reason: cantReason,
        requestedAt: new Date().toISOString().slice(0,10),
      } : null,
    }});
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Marked cannot fulfil" });
    if (req.deposit?.paid) dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Refund pending" });
    nav(`/coord/refund/${req.id}`);
  };

  return (
    <div className="max-w-6xl mx-auto px-6 py-12" data-testid="coord-review">
      <button onClick={() => nav("/coord/queue")} className="btn-ghost text-sm mb-4">← Request Queue</button>
      <div className="flex justify-between flex-wrap gap-4 mb-10">
        <div>
          <div className="section-eyebrow mb-2">{req.reference}</div>
          <h1 className="text-4xl font-serif">Review Wedding Requirements</h1>
          <p className="text-stone-600 mt-2">{req.client.name} · {req.weddingDate}</p>
        </div>
        <StatusBadge status={req.status} />
      </div>

      <div className="grid lg:grid-cols-[1fr_320px] gap-8">
        <div className="space-y-4">
          {findings.map((f, i) => (
            <div key={i} className="surface-card p-5" data-testid={`req-item-${i}`}>
              <div className="font-medium mb-3">{f.item}</div>
              <div className="grid md:grid-cols-[180px_1fr] gap-3 items-start">
                <div>
                  <label className="label-field">Fulfillable</label>
                  <select className="input-field" value={f.fulfillable} data-testid={`fulfill-${i}`}
                    onChange={(e) => updateF(i, { fulfillable: e.target.value })}>
                    <option value="yes">Yes</option>
                    <option value="unclear">Need clarification</option>
                    <option value="no">Cannot fulfill</option>
                  </select>
                </div>
                <div>
                  <label className="label-field">Notes</label>
                  <textarea rows={2} className="input-field" value={f.notes} data-testid={`notes-${i}`}
                    onChange={(e) => updateF(i, { notes: e.target.value })} />
                </div>
              </div>
            </div>
          ))}

          <div className="flex flex-wrap gap-2">
            <button className="btn-outline" onClick={saveFindings} data-testid="save-findings-btn">Save Findings</button>
            <button className="btn-ghost border border-stone-300" onClick={() => setAskOpen(true)} data-testid="ask-details-btn">
              Ask for Details
            </button>
            <button className="btn-ghost border border-red-800 text-red-800" onClick={() => setCantOpen(true)} data-testid="cant-fulfill-btn">
              Cannot Fulfill
            </button>
            <button className="btn-primary" disabled={!allFulfillable}
              onClick={() => nav(`/coord/approve/${req.id}`)}
              title={!allFulfillable ? "Every requirement must be marked fulfillable" : ""}
              data-testid="continue-approval-btn">
              Continue Approval
            </button>
          </div>
        </div>

        <aside className="surface-card p-6 h-fit">
          <div className="section-eyebrow mb-4">Client Details</div>
          <div className="text-sm space-y-2">
            <div><span className="text-stone-500">Phone: </span>{req.client.phone}</div>
            <div><span className="text-stone-500">Email: </span>{req.client.email}</div>
            <div><span className="text-stone-500">Address: </span>{req.client.address || "—"}</div>
            <div><span className="text-stone-500">Deposit: </span>{req.deposit?.paid ? `Received · ${req.deposit.reference}` : "—"}</div>
            <div><span className="text-stone-500">Review due: </span>{req.reviewDueAt}</div>
          </div>
        </aside>
      </div>

      {/* Ask details modal */}
      {askOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="ask-modal">
          <div className="surface-card p-8 max-w-lg w-full">
            <div className="section-eyebrow mb-2">Ask for Details</div>
            <h2 className="font-serif text-2xl mb-3">Message to client</h2>
            <textarea rows={5} className="input-field mb-4" value={askText} data-testid="ask-text"
              onChange={(e) => setAskText(e.target.value)} placeholder="Your question…" />
            <div className="flex justify-end gap-2">
              <button className="btn-ghost border border-stone-300" onClick={() => setAskOpen(false)}>Cancel</button>
              <button className="btn-primary" onClick={sendAsk} data-testid="send-ask-btn">Send</button>
            </div>
          </div>
        </div>
      )}

      {/* Cannot fulfill modal */}
      {cantOpen && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="cant-modal">
          <div className="surface-card p-8 max-w-lg w-full">
            <div className="section-eyebrow mb-2">Cannot Fulfill</div>
            <h2 className="font-serif text-2xl mb-3">Reason</h2>
            <p className="text-sm text-stone-600 mb-3">
              Mark at least one requirement as &quot;Cannot fulfill&quot; above before continuing. Enter a reason for the client:
            </p>
            <textarea rows={4} className="input-field mb-4" value={cantReason} data-testid="cant-reason"
              onChange={(e) => setCantReason(e.target.value)} />
            <div className="flex justify-end gap-2">
              <button className="btn-ghost border border-stone-300" onClick={() => setCantOpen(false)}>Cancel</button>
              <button className="btn-danger" onClick={submitCant} data-testid="submit-cant-btn">Proceed to Refund Review</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
