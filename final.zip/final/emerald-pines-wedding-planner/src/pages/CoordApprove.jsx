import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useApp, VENUES, iso } from "@/state/store";

export default function CoordApprove() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const req = state.requests.find((r) => r.id === id);
  const [agreed, setAgreed] = useState(false);
  const [method, setMethod] = useState("Email agreement");
  const [conflict, setConflict] = useState(false);

  if (!req) return <div className="p-12 text-center">Request not found</div>;
  const venue = VENUES.find((v) => v.id === req.venueId);

  const checkConflict = () => {
    if (state.presentation.forceConflict) return true;
    return state.requests.some(
      (r) => r.id !== req.id && r.status === "confirmed" && r.weddingDate === req.weddingDate && r.venueId === req.venueId,
    ) || state.closures.some((c) => c.date === req.weddingDate && (!c.venueId || c.venueId === req.venueId));
  };

  const confirm = () => {
    if (!agreed) { toast.error("Record the client agreement first"); return; }
    if (checkConflict()) {
      setConflict(true);
      dispatch({ type: "SET_PRESENTATION", patch: { forceConflict: false } });
      return;
    }
    const reservation = {
      reference: `RSV-${55100 + state.requests.length}`,
      confirmedAt: iso(new Date()),
      method,
    };
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: {
      status: "confirmed", reservation,
      coordinatorMessage: "Your reservation is confirmed. We look forward to hosting you.",
    }});
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Reservation confirmed" });
    toast.success("Reservation confirmed · date marked unavailable");
    nav("/coord/queue");
  };

  return (
    <div className="max-w-5xl mx-auto px-6 py-12" data-testid="coord-approve">
      <button onClick={() => nav(`/coord/review/${req.id}`)} className="btn-ghost text-sm mb-4">← Review</button>
      <div className="section-eyebrow mb-2">{req.reference}</div>
      <h1 className="text-4xl font-serif mb-8">Approve &amp; Confirm</h1>

      <div className="grid md:grid-cols-[1fr_320px] gap-8">
        <div className="surface-card p-8 space-y-5" style={{ borderColor: "#D4AF37" }}>
          <section>
            <div className="section-eyebrow mb-2">Wedding Plan</div>
            <div className="text-sm space-y-1">
              <div>{req.client.name}</div>
              <div>{venue?.name} · {req.weddingDate} · {req.guestCount} guests</div>
            </div>
          </section>
          <div className="divider-gold" />
          <section>
            <div className="section-eyebrow mb-2">Findings</div>
            <ul className="text-sm space-y-2">
              {req.findings.map((f, i) => (
                <li key={i} className="flex justify-between gap-4">
                  <span>{f.item}</span>
                  <span className="emerald-ink capitalize">{f.fulfillable}</span>
                </li>
              ))}
            </ul>
          </section>
          <div className="divider-gold" />
          <section className="grid sm:grid-cols-2 gap-4 text-sm">
            <div><span className="text-stone-500">Deposit: </span>Received · {req.deposit?.reference}</div>
            <div><span className="text-stone-500">Review due: </span>{req.reviewDueAt}</div>
          </section>
        </div>

        <aside className="space-y-4">
          <div className="surface-card p-5">
            <div className="section-eyebrow mb-3">Client Agreement</div>
            <label className="flex items-start gap-2 text-sm mb-3 cursor-pointer">
              <input type="checkbox" className="mt-1 accent-emerald-900" checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)} data-testid="agreed-checkbox" />
              <span>Client has agreed to the plan.</span>
            </label>
            <label className="label-field">Method</label>
            <select className="input-field" value={method} onChange={(e) => setMethod(e.target.value)} data-testid="agree-method">
              <option>Email agreement</option>
              <option>Phone call</option>
              <option>In-person signature</option>
            </select>
          </div>
          <button className="btn-primary w-full justify-center" onClick={confirm} data-testid="confirm-reservation-btn">
            Confirm Reservation
          </button>
          <p className="text-xs text-stone-500 italic">
            No second deposit is required. The client receives a message in their Request Status.
          </p>
        </aside>
      </div>

      {conflict && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="conflict-modal">
          <div className="surface-card p-8 max-w-lg w-full">
            <div className="section-eyebrow mb-1 text-red-800">Date Conflict</div>
            <h2 className="font-serif text-2xl mb-3">Final date check failed</h2>
            <p className="text-sm text-stone-600 mb-6">
              {req.weddingDate} for {venue?.name} is no longer available. Please choose another date or return to review.
            </p>
            <div className="flex justify-end gap-2">
              <button className="btn-ghost border border-stone-300" onClick={() => { setConflict(false); nav(`/coord/review/${req.id}`); }} data-testid="conflict-return-btn">
                Return to Review
              </button>
              <button className="btn-primary" onClick={() => { setConflict(false); nav("/coord/venue"); }} data-testid="conflict-change-date-btn">
                Change Date
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
