import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ChevronDown } from "lucide-react";

const TOPICS = [
  { q: "Staff roles explained", a: "Coordinators review wedding plans and issue refunds. Administrators manage staff records." },
  { q: "Editing an account", a: "Open the staff list, choose Edit, and update name, email, role, or active status." },
  { q: "Deactivating an account", a: "Deactivation marks the account inactive while preserving prior review history. The global View-as selector is unaffected." },
];

export default function AdminHelp() {
  const nav = useNavigate();
  const [open, setOpen] = useState(0);
  return (
    <div className="max-w-4xl mx-auto px-6 py-12" data-testid="admin-help">
      <button onClick={() => nav(-1)} className="btn-ghost text-sm mb-4">← Back</button>
      <div className="section-eyebrow mb-2">Administrator</div>
      <h1 className="text-4xl font-serif mb-8">Help &amp; Procedures</h1>
      <div className="space-y-2">
        {TOPICS.map((t, i) => (
          <button key={i} onClick={() => setOpen(open === i ? -1 : i)} className="w-full text-left surface-card p-5" data-testid={`admin-help-${i}`}>
            <div className="flex justify-between items-center">
              <span className="font-medium">{t.q}</span>
              <ChevronDown className={`w-4 h-4 transition-transform ${open === i ? "rotate-180" : ""}`} />
            </div>
            {open === i && <p className="mt-3 text-sm text-stone-600">{t.a}</p>}
          </button>
        ))}
      </div>
      <button className="btn-outline mt-6" onClick={() => nav("/admin")}>Home</button>
    </div>
  );
}
