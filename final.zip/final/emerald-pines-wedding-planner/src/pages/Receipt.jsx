import React from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { Printer, Home as HomeIcon, LifeBuoy } from "lucide-react";
import { useApp, VENUES } from "@/state/store";

export default function Receipt() {
  const { state } = useApp();
  const { id } = useParams();
  const nav = useNavigate();
  const req = state.requests.find((r) => r.id === id);

  if (!req) return (
    <div className="max-w-3xl mx-auto px-6 py-24 text-center">
      <h2 className="font-serif text-3xl">Receipt not found</h2>
    </div>
  );

  const venue = VENUES.find((v) => v.id === req.venueId);
  const mode =
    req.refund ? "refund" :
    req.reservation ? "reservation" :
    req.deposit?.paid ? "deposit" : "deposit";

  return (
    <div className="max-w-3xl mx-auto px-6 py-12" data-testid="receipt-page">
      <button onClick={() => nav(-1)} className="btn-ghost text-sm mb-4">← Back</button>

      <div className="surface-card p-10 print:shadow-none" style={{ borderColor: "#D4AF37" }}>
        <div className="flex justify-between items-start mb-8 pb-6 border-b border-stone-200">
          <div>
            <div className="section-eyebrow mb-1">Emerald Pines Country Club</div>
            <h1 className="font-serif text-3xl">
              {mode === "refund" ? "Refund Record" : mode === "reservation" ? "Reservation Confirmation" : "Deposit Receipt"}
            </h1>
          </div>
          <div className="text-xs text-stone-500 text-right">
            <div>Issued {new Date().toLocaleDateString()}</div>
            <div>{req.reference}</div>
          </div>
        </div>

        {mode === "deposit" && (
          <>
            <div className="grid sm:grid-cols-2 gap-5 text-sm mb-6">
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Amount</span><span className="font-serif text-2xl">$100</span></div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Reference</span>{req.deposit.reference}</div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Status</span>Under Review</div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Review Due</span>{req.reviewDueAt}</div>
            </div>
            <p className="text-xs text-stone-500 italic">
              This receipt acknowledges the application deposit. It is not a confirmed booking.
            </p>
          </>
        )}

        {mode === "reservation" && (
          <div className="grid sm:grid-cols-2 gap-5 text-sm mb-6">
            <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Reservation</span>{req.reservation.reference}</div>
            <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Confirmed</span>{req.reservation.confirmedAt}</div>
            <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Venue</span>{venue?.name}</div>
            <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Date</span>{req.weddingDate}</div>
            <div className="sm:col-span-2"><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Agreed facilities</span>{req.otherFacilities || "—"}</div>
          </div>
        )}

        {mode === "refund" && (
          <>
            <div className="grid sm:grid-cols-2 gap-5 text-sm mb-6">
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Amount</span><span className="font-serif text-2xl">${req.refund.amount}</span></div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Reference</span>{req.refund.reference}</div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Status</span><span className="capitalize">{req.refund.status}</span></div>
              <div><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Requested</span>{req.refund.requestedAt}</div>
              <div className="sm:col-span-2"><span className="text-stone-500 block text-xs uppercase tracking-widest mb-1">Reason</span>{req.refund.reason}</div>
            </div>
          </>
        )}

        <div className="divider-gold my-6" />
        <div className="text-xs text-stone-500 italic">
          Presentation only. No real payment is processed.
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-6 print:hidden">
        <button className="btn-primary" onClick={() => window.print()} data-testid="print-receipt-btn">
          <Printer className="w-4 h-4" /> Print Receipt
        </button>
        <button className="btn-outline" onClick={() => nav(`/status/${req.id}`)} data-testid="view-status-btn">
          View Status
        </button>
        <Link to="/" className="btn-ghost border border-stone-300" data-testid="home-btn">
          <HomeIcon className="w-4 h-4" /> Home
        </Link>
        <Link to="/help" className="btn-ghost border border-stone-300" data-testid="help-btn">
          <LifeBuoy className="w-4 h-4" /> Help
        </Link>
      </div>
    </div>
  );
}
