import React, { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { toast } from "sonner";
import { useApp, VENUES } from "@/state/store";

export default function CoordRefund() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const req = state.requests.find((r) => r.id === id);
  const [confirm, setConfirm] = useState(false);

  if (!req) return <div className="p-12 text-center">Request not found</div>;

  const venue = VENUES.find((v) => v.id === req.venueId);
  const hasDeposit = req.deposit?.paid;
  const hasReservation = !!req.reservation;

  const issueRefund = () => {
    // Ensure refund record exists
    const refund = req.refund || {
      amount: 100,
      reference: `RFD-${33200 + state.requests.length}`,
      status: "pending",
      reason: req.coordinatorMessage || "Unfulfillable request",
      requestedAt: new Date().toISOString().slice(0, 10),
    };
    const patch = { refund };
    if (hasReservation) {
      patch.reservation = null;
      dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Reservation cancelled · date released" });
    }
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch });
    toast.success("Refund initiated");
    nav(`/coord/refund/${req.id}/processing`);
  };

  const closeRequest = () => {
    dispatch({ type: "PATCH_REQUEST", id: req.id, patch: { status: "cannot_fulfill" } });
    dispatch({ type: "APPEND_TIMELINE", id: req.id, label: "Request closed" });
    toast.success("Request closed");
    nav("/coord/queue");
  };

  return (
    <div className="max-w-4xl mx-auto px-6 py-12" data-testid="coord-refund">
      <button onClick={() => nav(`/coord/review/${req.id}`)} className="btn-ghost text-sm mb-4">← Back to Review</button>
      <div className="section-eyebrow mb-2">{req.reference}</div>
      <h1 className="text-4xl font-serif mb-8">Cannot Fulfill &amp; Refund Review</h1>

      <div className="surface-card p-8 space-y-5" style={{ borderColor: "#D4AF37" }}>
        <div>
          <div className="section-eyebrow mb-2">Plan</div>
          <div className="text-sm">{req.client.name} · {venue?.name} · {req.weddingDate}</div>
        </div>
        <div className="divider-gold" />
        <div>
          <div className="section-eyebrow mb-2">Unmet Requirements</div>
          <ul className="text-sm space-y-1">
            {req.findings.filter((f) => f.fulfillable === "no").map((f, i) => (
              <li key={i}>• {f.item} — {f.notes || "No notes"}</li>
            ))}
            {!req.findings.some((f) => f.fulfillable === "no") && (
              <li className="text-stone-500">No requirements marked unfulfillable.</li>
            )}
          </ul>
        </div>
        <div className="divider-gold" />
        <div>
          <div className="section-eyebrow mb-2">Explanation to client</div>
          <p className="text-sm text-stone-700">{req.coordinatorMessage || "—"}</p>
        </div>
        <div className="divider-gold" />
        <div className="grid sm:grid-cols-2 gap-4 text-sm">
          <div><span className="text-stone-500">Deposit: </span>{hasDeposit ? `$${req.deposit.amount} · ${req.deposit.reference}` : "None"}</div>
          <div><span className="text-stone-500">Reservation: </span>{hasReservation ? req.reservation.reference : "None"}</div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mt-6">
        {hasDeposit ? (
          <button className="btn-danger" onClick={() => setConfirm(true)} data-testid="issue-refund-btn">
            Issue Full $100 Refund
          </button>
        ) : (
          <button className="btn-primary" onClick={closeRequest} data-testid="close-request-btn">
            Close Request (no deposit on file)
          </button>
        )}
        <button className="btn-ghost border border-stone-300" onClick={() => nav(`/coord/review/${req.id}`)} data-testid="back-btn">
          Back
        </button>
      </div>

      {confirm && (
        <div className="fixed inset-0 bg-black/40 backdrop-blur-sm flex items-center justify-center z-50 p-6" data-testid="confirm-refund-modal">
          <div className="surface-card p-8 max-w-md w-full">
            <h2 className="font-serif text-2xl mb-3">Issue Full Refund?</h2>
            <p className="text-sm text-stone-600 mb-6">
              This will refund the full $100 deposit to {req.client.name}.
              {hasReservation && " The existing reservation will be cancelled and the date released."}
            </p>
            <div className="flex justify-end gap-2">
              <button className="btn-ghost border border-stone-300" onClick={() => setConfirm(false)}>Cancel</button>
              <button className="btn-danger" onClick={() => { setConfirm(false); issueRefund(); }} data-testid="confirm-refund-btn">
                Confirm Refund
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
