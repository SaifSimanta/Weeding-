import React, { useEffect, useMemo, useRef, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { ArrowLeft, Sparkles, Undo2 } from "lucide-react";
import { useApp, VENUES } from "@/state/store";

const EMPTY = {
  name: "", phone: "", email: "", address: "",
  venueId: "pine-grove", weddingDate: "",
  guestCount: 100,
  cultural: { enabled: false, details: "" },
  silentDisco: { enabled: false, details: "" },
  otherFacilities: "", services: "",
};

const EXAMPLE = {
  name: "Harper & Lee Fontaine",
  phone: "(555) 912-0043",
  email: "harper.fontaine@example.com",
  address: "223 Maple Crescent, Woodstock, VT",
  venueId: "pine-grove",
  weddingDate: "2026-09-26",
  guestCount: 165,
  cultural: { enabled: true, details: "Jewish ceremony under a chuppah with ketubah signing." },
  silentDisco: { enabled: true, details: "150 headsets, 3 channels, run 9pm–midnight." },
  otherFacilities: "Golf-cart shuttle, outdoor heaters, string-light arbour.",
  services: "Plated kosher-style dinner, dessert bar, late-night snack cart.",
};

function validate(f) {
  const errs = {};
  if (!f.name.trim()) errs.name = "Full name is required.";
  if (!f.phone.trim()) errs.phone = "Phone number is required.";
  if (!f.email.trim()) errs.email = "Email is required.";
  else if (!/^\S+@\S+\.\S+$/.test(f.email)) errs.email = "Enter a valid email.";
  if (!f.venueId) errs.venueId = "Preferred venue is required.";
  if (!f.weddingDate) errs.weddingDate = "Wedding date is required.";
  if (!f.guestCount || f.guestCount < 1) errs.guestCount = "Guest count required.";
  if (f.cultural.enabled && !f.cultural.details.trim())
    errs.cultural = "Describe your cultural arrangements.";
  if (f.silentDisco.enabled && !f.silentDisco.details.trim())
    errs.silentDisco = "Describe your silent disco needs.";
  return errs;
}

export default function PlanForm() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const loc = useLocation();

  const active = state.requests.find((r) => r.id === state.activeRequestId);
  const seedFromActive = active && (active.status === "draft" || loc.state?.editing)
    ? {
        name: active.client.name,
        phone: active.client.phone,
        email: active.client.email,
        address: active.client.address,
        venueId: active.venueId,
        weddingDate: active.weddingDate,
        guestCount: active.guestCount,
        cultural: active.cultural,
        silentDisco: active.silentDisco,
        otherFacilities: active.otherFacilities,
        services: active.services,
      }
    : EMPTY;

  const [form, setForm] = useState({
    ...seedFromActive,
    ...(loc.state?.venueId ? { venueId: loc.state.venueId } : {}),
    ...(loc.state?.weddingDate ? { weddingDate: loc.state.weddingDate } : {}),
  });
  const [errors, setErrors] = useState({});
  const lastSaved = useRef(form);

  useEffect(() => { lastSaved.current = form; /* capture initial */ }, []); // eslint-disable-line

  const update = (patch) => setForm((f) => ({ ...f, ...patch }));

  const onSaveDraft = () => {
    lastSaved.current = form;
    toast.success("Draft saved locally");
  };

  const onLoadExample = () => {
    setForm(EXAMPLE);
    lastSaved.current = EXAMPLE;
    toast.success("Example loaded");
  };

  const onUndo = () => {
    setForm(lastSaved.current);
    toast.success("Changes reverted to last saved version");
  };

  const onDiscard = () => {
    if (window.confirm("Discard this draft? This cannot be undone.")) {
      setForm(EMPTY);
      lastSaved.current = EMPTY;
      toast.success("Draft discarded");
      nav("/");
    }
  };

  const onReview = () => {
    const errs = validate(form);
    setErrors(errs);
    if (Object.keys(errs).length) {
      toast.error("Please complete required fields");
      return;
    }
    // Persist draft into state for review screen
    const id = active && (active.status === "draft" || loc.state?.editing)
      ? active.id
      : `DRAFT-${Date.now()}`;
    const req = active && (active.status === "draft" || loc.state?.editing)
      ? { ...active,
          client: { name: form.name, phone: form.phone, email: form.email, address: form.address },
          venueId: form.venueId, weddingDate: form.weddingDate, guestCount: form.guestCount,
          cultural: form.cultural, silentDisco: form.silentDisco,
          otherFacilities: form.otherFacilities, services: form.services,
        }
      : {
          id, reference: id, client: { name: form.name, phone: form.phone, email: form.email, address: form.address },
          venueId: form.venueId, weddingDate: form.weddingDate, guestCount: form.guestCount,
          cultural: form.cultural, silentDisco: form.silentDisco,
          otherFacilities: form.otherFacilities, services: form.services,
          status: "draft", submittedAt: null, reviewDueAt: null,
          deposit: { paid: false, amount: 0, reference: null, date: null },
          findings: [], coordinatorMessage: "", reservation: null, refund: null,
          timeline: [{ label: "Draft saved", at: new Date().toISOString().slice(0,10) }],
        };
    dispatch({ type: "UPSERT_REQUEST", request: req });
    nav("/review");
  };

  const chosenVenue = useMemo(
    () => VENUES.find((v) => v.id === form.venueId),
    [form.venueId],
  );

  return (
    <div className="max-w-5xl mx-auto px-6 py-12" data-testid="plan-form">
      <button onClick={() => nav("/")} className="btn-ghost text-sm mb-4" data-testid="back-btn">
        <ArrowLeft className="w-4 h-4 inline mr-1" /> Back
      </button>
      <div className="flex items-start justify-between gap-6 flex-wrap mb-8">
        <div>
          <div className="section-eyebrow mb-2">Wedding Plan</div>
          <h1 className="text-4xl md:text-5xl font-serif mb-2">Share your vision</h1>
          <p className="text-stone-600 max-w-xl">
            Every field helps our coordinators evaluate your request. You may save
            a draft and return at any time.
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          <button className="btn-ghost text-sm border border-stone-300" onClick={onLoadExample} data-testid="load-example-btn">
            <Sparkles className="w-3.5 h-3.5 inline mr-1" /> Load Example
          </button>
          <button className="btn-ghost text-sm border border-stone-300" onClick={onUndo} data-testid="undo-btn">
            <Undo2 className="w-3.5 h-3.5 inline mr-1" /> Undo Changes
          </button>
        </div>
      </div>

      <div className="space-y-10">
        {/* Contact */}
        <section className="surface-card p-8">
          <div className="section-eyebrow mb-4">Contact Details</div>
          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <label className="label-field">Full name *</label>
              <input className="input-field" value={form.name} data-testid="field-name"
                onChange={(e) => update({ name: e.target.value })} />
              {errors.name && <p className="text-xs text-red-800 mt-1">{errors.name}</p>}
            </div>
            <div>
              <label className="label-field">Phone *</label>
              <input className="input-field" value={form.phone} data-testid="field-phone"
                onChange={(e) => update({ phone: e.target.value })} />
              {errors.phone && <p className="text-xs text-red-800 mt-1">{errors.phone}</p>}
            </div>
            <div>
              <label className="label-field">Email *</label>
              <input className="input-field" value={form.email} data-testid="field-email"
                onChange={(e) => update({ email: e.target.value })} />
              {errors.email && <p className="text-xs text-red-800 mt-1">{errors.email}</p>}
            </div>
            <div>
              <label className="label-field">Address</label>
              <input className="input-field" value={form.address} data-testid="field-address"
                onChange={(e) => update({ address: e.target.value })} />
            </div>
          </div>
        </section>

        {/* Venue + Date */}
        <section className="surface-card p-8">
          <div className="flex items-center justify-between flex-wrap gap-3 mb-4">
            <div className="section-eyebrow">Venue &amp; Date</div>
            <button className="text-xs text-emerald-900 underline" data-testid="change-date-btn"
              onClick={() => nav("/availability", { state: form })}>
              Change date in calendar
            </button>
          </div>
          <div className="grid md:grid-cols-3 gap-5">
            <div>
              <label className="label-field">Preferred venue *</label>
              <select className="input-field" value={form.venueId} data-testid="field-venue"
                onChange={(e) => update({ venueId: e.target.value })}>
                {VENUES.map((v) => <option key={v.id} value={v.id}>{v.name}</option>)}
              </select>
              {chosenVenue && (
                <p className="text-xs text-stone-500 mt-1">
                  {chosenVenue.kind} · up to {chosenVenue.capacity} guests
                </p>
              )}
            </div>
            <div>
              <label className="label-field">Wedding date *</label>
              <input type="date" className="input-field" value={form.weddingDate} data-testid="field-date"
                onChange={(e) => update({ weddingDate: e.target.value })} />
              {errors.weddingDate && <p className="text-xs text-red-800 mt-1">{errors.weddingDate}</p>}
            </div>
            <div>
              <label className="label-field">Guest count *</label>
              <input type="number" className="input-field" value={form.guestCount} data-testid="field-guests"
                onChange={(e) => update({ guestCount: parseInt(e.target.value || "0", 10) })} />
              {errors.guestCount && <p className="text-xs text-red-800 mt-1">{errors.guestCount}</p>}
            </div>
          </div>
        </section>

        {/* Cultural + Silent Disco */}
        <section className="surface-card p-8">
          <div className="section-eyebrow mb-4">Special Arrangements</div>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="flex items-center gap-2 cursor-pointer mb-2">
                <input type="checkbox" className="accent-emerald-900"
                  checked={form.cultural.enabled} data-testid="field-cultural"
                  onChange={(e) => update({ cultural: { ...form.cultural, enabled: e.target.checked } })} />
                <span className="font-medium">Cultural arrangements</span>
              </label>
              {form.cultural.enabled && (
                <>
                  <textarea rows={3} className="input-field" placeholder="Describe ceremonies, rituals, cultural staging..."
                    value={form.cultural.details} data-testid="field-cultural-details"
                    onChange={(e) => update({ cultural: { ...form.cultural, details: e.target.value } })} />
                  {errors.cultural && <p className="text-xs text-red-800 mt-1">{errors.cultural}</p>}
                </>
              )}
            </div>
            <div>
              <label className="flex items-center gap-2 cursor-pointer mb-2">
                <input type="checkbox" className="accent-emerald-900"
                  checked={form.silentDisco.enabled} data-testid="field-disco"
                  onChange={(e) => update({ silentDisco: { ...form.silentDisco, enabled: e.target.checked } })} />
                <span className="font-medium">Silent disco</span>
              </label>
              {form.silentDisco.enabled && (
                <>
                  <textarea rows={3} className="input-field" placeholder="Headsets needed, channels, hours..."
                    value={form.silentDisco.details} data-testid="field-disco-details"
                    onChange={(e) => update({ silentDisco: { ...form.silentDisco, details: e.target.value } })} />
                  {errors.silentDisco && <p className="text-xs text-red-800 mt-1">{errors.silentDisco}</p>}
                </>
              )}
            </div>
          </div>
        </section>

        {/* Facilities + Services */}
        <section className="surface-card p-8">
          <div className="section-eyebrow mb-4">Facilities &amp; Services</div>
          <div className="grid md:grid-cols-2 gap-5">
            <div>
              <label className="label-field">Other requested facilities</label>
              <textarea rows={4} className="input-field" data-testid="field-facilities"
                placeholder="Shuttle, decor accents, signage, equipment..."
                value={form.otherFacilities}
                onChange={(e) => update({ otherFacilities: e.target.value })} />
            </div>
            <div>
              <label className="label-field">Service notes</label>
              <textarea rows={4} className="input-field" data-testid="field-services"
                placeholder="Catering style, dietary notes, bar service..."
                value={form.services}
                onChange={(e) => update({ services: e.target.value })} />
            </div>
          </div>
        </section>

        <div className="flex flex-wrap gap-3 justify-between items-center">
          <div className="flex gap-2 flex-wrap">
            <button className="btn-outline" onClick={onSaveDraft} data-testid="save-draft-btn">Save Draft</button>
            <button className="btn-ghost border border-red-800 text-red-800" onClick={onDiscard} data-testid="discard-draft-btn">
              Discard Draft
            </button>
            <button className="btn-ghost border border-stone-300" onClick={() => nav("/")} data-testid="cancel-btn">
              Cancel
            </button>
          </div>
          <button className="btn-primary" onClick={onReview} data-testid="review-plan-btn">
            Review Plan
          </button>
        </div>
      </div>
    </div>
  );
}
