import React from "react";
import { useNavigate, useParams, Link } from "react-router-dom";
import { ArrowLeft, Pencil, MessageCircle, FileText, RefreshCcw } from "lucide-react";
import { useApp, VENUES } from "@/state/store";
import StatusBadge, { Timeline } from "@/components/StatusBadge";

export default function RequestStatus() {
  const { state, dispatch } = useApp();
  const nav = useNavigate();
  const { id } = useParams();
  const reqId = id || state.activeRequestId;
  const req = state.requests.find((r) => r.id === reqId);

  if (!req) return (
    <div className="max-w-3xl mx-auto px-6 py-24 text-center">
      <h2 className="font-serif text-3xl mb-3">No active request</h2>
      <Link to="/plan" className="btn-primary">Start a plan</Link>
    </div>
  );

  const venue = VENUES.find((v) => v.id === req.venueId);
  const refundTone =
    req.refund?.status === "completed" ? "text-emerald-900" :
    req.refund?.status === "failed" ? "text-red-800" : "text-amber-900";

  return (
    <div className="max-w-5xl mx-auto px-6 py-12" data-testid="request-status">
      <button onClick={() => nav(-1)} className="btn-ghost text-sm mb-4" data-testid="back-btn">
        <ArrowLeft className="w-4 h-4 inline mr-1" /> Back
      </button>
      <div className="flex justify-between flex-wrap items-start gap-4 mb-10">
        <div>
          <div className="section-eyebrow mb-2">Reference {req.reference}</div>
          <h1 className="text-4xl md:text-5xl font-serif mb-2">Request Status</h1>
          <p className="text-stone-600">
            {req.client.name} · {venue?.name} · {req.weddingDate}
          </p>
        </div>
        <StatusBadge status={req.status} />
      </div>

      <div className="grid md:grid-cols-[1fr_320px] gap-8">
        <div className="space-y-6">
          <div className="surface-card p-6">
            <div className="section-eyebrow mb-3">Summary</div>
            <div className="grid sm:grid-cols-2 gap-4 text-sm">
              <div><span className="text-stone-500">Submitted: </span>{req.submittedAt || "—"}</div>
              <div><span className="text-stone-500">Review due: </span>{req.reviewDueAt || "—"}</div>
              <div><span className="text-stone-500">Guests: </span>{req.guestCount}</div>
              <div><span className="text-stone-500">Deposit: </span>
                {req.deposit?.paid ? `Received · ${req.deposit.reference}` : "Not received"}
              </div>
            </div>
          </div>

          {req.coordinatorMessage && (
            <div className="surface-card p-6" style={{ borderColor: "#D4AF37" }}>
              <div className="section-eyebrow mb-2 flex items-center gap-2">
                <MessageCircle className="w-3.5 h-3.5" /> Coordinator Message
              </div>
              <p className="text-sm text-stone-800 leading-relaxed">{req.coordinatorMessage}</p>
            </div>
          )}

          {req.reservation && (
            <div className="surface-card p-6">
              <div className="section-eyebrow mb-3">Reservation Confirmed</div>
              <div className="grid sm:grid-cols-2 gap-3 text-sm">
                <div><span className="text-stone-500">Reference: </span>{req.reservation.reference}</div>
                <div><span className="text-stone-500">Confirmed: </span>{req.reservation.confirmedAt}</div>
                <div><span className="text-stone-500">Venue: </span>{venue?.name}</div>
                <div><span className="text-stone-500">Date: </span>{req.weddingDate}</div>
              </div>
            </div>
          )}

          {req.refund && (
            <div className="surface-card p-6">
              <div className="section-eyebrow mb-3">Refund</div>
              <div className="text-sm space-y-2">
                <div><span className="text-stone-500">Amount: </span>${req.refund.amount}</div>
                <div><span className="text-stone-500">Reference: </span>{req.refund.reference}</div>
                <div>
                  <span className="text-stone-500">Status: </span>
                  <span className={`font-medium capitalize ${refundTone}`} data-testid="refund-status">
                    {req.refund.status}
                  </span>
                </div>
                <div className="text-stone-600 text-sm mt-2">{req.refund.reason}</div>
              </div>
            </div>
          )}

          <div className="flex flex-wrap gap-2">
            <button className="btn-outline" onClick={() => nav("/review")} data-testid="view-plan-btn">
              <FileText className="w-4 h-4" /> View Plan
            </button>
            {(req.status === "needs_info" || req.status === "under_review") && (
              <button className="btn-primary" onClick={() => {
                dispatch({ type: "SET_ACTIVE_REQUEST", id: req.id });
                nav("/plan", { state: { editing: true } });
              }} data-testid="respond-revise-btn">
                <Pencil className="w-4 h-4" />
                {req.status === "needs_info" ? "Respond / Revise Plan" : "Revise Plan"}
              </button>
            )}
            {(req.deposit?.paid || req.refund) && (
              <button className="btn-outline" onClick={() => nav(`/receipt/${req.id}`)} data-testid="view-receipt-btn">
                View Receipt / Refund
              </button>
            )}
            <Link to="/help" state={{ requestRef: req.reference }} className="btn-ghost border border-stone-300" data-testid="contact-coord-btn">
              Contact Coordinator
            </Link>
          </div>
        </div>

        <aside>
          <div className="surface-card p-6">
            <div className="section-eyebrow mb-4 flex items-center gap-2">
              <RefreshCcw className="w-3.5 h-3.5" /> Progress
            </div>
            <Timeline items={req.timeline} />
          </div>
        </aside>
      </div>
    </div>
  );
}
