import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Sparkles, ArrowRight } from "lucide-react";
import Logo from "@/components/Logo";
import { useApp } from "@/state/store";

const HERO =
  "https://images.pexels.com/photos/33079800/pexels-photo-33079800.jpeg";

const DEMO_ACCOUNTS = [
  {
    id: "client",
    role: "client",
    label: "Wedding Client",
    name: "Amelia Caldwell",
    email: "amelia.caldwell@example.com",
    password: "demo1234",
    blurb: "Plan a wedding, submit for review, pay the simulated deposit, track status.",
    to: "/",
  },
  {
    id: "coordinator",
    role: "coordinator",
    label: "Coordinator",
    name: "Elena Rhodes",
    email: "elena.rhodes@emeraldpines.club",
    password: "demo1234",
    blurb: "Review wedding requirements, confirm reservations, process refunds.",
    to: "/coord",
  },
  {
    id: "administrator",
    role: "administrator",
    label: "Administrator",
    name: "Yasmin Park",
    email: "yasmin.park@emeraldpines.club",
    password: "demo1234",
    blurb: "Manage staff accounts and roles.",
    to: "/admin",
  },
];

export default function Login() {
  const { dispatch } = useApp();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [choice, setChoice] = useState("client");

  const quickFill = (acct) => {
    setChoice(acct.role);
    setEmail(acct.email);
    setPassword(acct.password);
  };

  const signIn = (role, to) => {
    if (!email.trim() || !password.trim()) {
      toast.error("Enter any email and password to continue");
      return;
    }
    dispatch({ type: "SET_LOGIN", session: { email, role, name: email.split("@")[0] } });
    dispatch({ type: "SET_VIEW", view: role });
    toast.success(`Signed in as ${role}`);
    nav(to);
  };

  return (
    <div className="min-h-screen grid md:grid-cols-2" data-testid="login-page">
      {/* Left: Hero image */}
      <div className="relative hidden md:block">
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${HERO})` }}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(140deg, rgba(10,61,45,0.92) 0%, rgba(10,61,45,0.6) 55%, rgba(10,61,45,0.35) 100%)",
          }}
        />
        <div className="relative h-full flex flex-col justify-between p-12 text-ivory" style={{ color: "#FDFBF7" }}>
          <Logo variant="light" />
          <div>
            <div
              className="text-xs tracking-[0.35em] uppercase mb-3"
              style={{ color: "#D4AF37" }}
            >
              Demo Presentation
            </div>
            <h1 className="font-serif text-4xl lg:text-5xl leading-tight mb-4">
              A legacy begins beneath our pines.
            </h1>
            <p className="text-stone-100/90 font-light max-w-sm leading-relaxed">
              Sign in with any email and password, or tap a role card for a one-click
              demo. All data is fictional.
            </p>
          </div>
        </div>
      </div>

      {/* Right: Form */}
      <div className="flex flex-col justify-center p-6 md:p-12 surface-ivory">
        <div className="md:hidden mb-8">
          <Logo />
        </div>
        <div className="max-w-md w-full mx-auto">
          <div className="section-eyebrow mb-2">Sign in</div>
          <h2 className="font-serif text-4xl mb-2">Welcome back</h2>
          <p className="text-sm text-stone-600 mb-8">
            Any email and password works for this demo. Pick a role below.
          </p>

          {/* Role cards */}
          <div className="grid gap-2 mb-6">
            {DEMO_ACCOUNTS.map((acct) => (
              <button
                key={acct.id}
                onClick={() => quickFill(acct)}
                data-testid={`role-card-${acct.id}`}
                className={`text-left p-4 border rounded-sm transition-colors ${
                  choice === acct.role
                    ? "border-emerald-900 bg-emerald-50/40"
                    : "border-stone-200 hover:border-stone-400 bg-white"
                }`}
                style={choice === acct.role ? { borderColor: "#0A3D2D" } : {}}
              >
                <div className="flex items-center justify-between mb-1">
                  <div className="font-serif text-lg">{acct.label}</div>
                  {choice === acct.role && (
                    <span className="text-xs emerald-ink flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> Selected
                    </span>
                  )}
                </div>
                <div className="text-xs text-stone-500">{acct.blurb}</div>
              </button>
            ))}
          </div>

          <div className="space-y-3 mb-5">
            <div>
              <label className="label-field">Email</label>
              <input
                type="email"
                className="input-field"
                placeholder="anyone@example.com"
                value={email}
                data-testid="login-email"
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <label className="label-field">Password</label>
              <input
                type="password"
                className="input-field"
                placeholder="anything"
                value={password}
                data-testid="login-password"
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <button
            className="btn-primary w-full justify-center"
            data-testid="login-submit"
            onClick={() => {
              const acct = DEMO_ACCOUNTS.find((a) => a.role === choice);
              signIn(acct.role, acct.to);
            }}
          >
            Sign In as {DEMO_ACCOUNTS.find((a) => a.role === choice)?.label}
            <ArrowRight className="w-4 h-4" />
          </button>

          <div className="text-xs text-stone-500 text-center mt-6 italic">
            Presentation only. No real authentication is performed.
          </div>
        </div>
      </div>
    </div>
  );
}
