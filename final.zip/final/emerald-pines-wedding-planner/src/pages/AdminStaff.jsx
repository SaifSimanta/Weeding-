import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useApp } from "@/state/store";

export default function AdminStaff() {
  const { state } = useApp();
  const nav = useNavigate();
  const [q, setQ] = useState("");
  const [role, setRole] = useState("all");
  const [active, setActive] = useState("all");

  const list = state.staff.filter((s) => {
    const t = q.toLowerCase();
    if (q && !(s.name.toLowerCase().includes(t) || s.email.toLowerCase().includes(t))) return false;
    if (role !== "all" && s.role !== role) return false;
    if (active !== "all" && (active === "active") !== s.active) return false;
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto px-6 py-12" data-testid="admin-staff">
      <button onClick={() => nav("/admin")} className="btn-ghost text-sm mb-4">← Home</button>
      <div className="flex justify-between items-start flex-wrap gap-4 mb-10">
        <div>
          <div className="section-eyebrow mb-2">Administrator</div>
          <h1 className="text-4xl font-serif">Staff Accounts</h1>
        </div>
        <Link to="/admin/staff/new" className="btn-primary" data-testid="create-staff-btn">Create Staff Account</Link>
      </div>

      <div className="flex gap-3 mb-6 flex-wrap">
        <input className="input-field max-w-sm" placeholder="Search name or email…" value={q}
          onChange={(e) => setQ(e.target.value)} data-testid="staff-search" />
        <select className="input-field max-w-xs" value={role} onChange={(e) => setRole(e.target.value)} data-testid="staff-role-filter">
          <option value="all">All roles</option>
          <option value="Coordinator">Coordinator</option>
          <option value="Administrator">Administrator</option>
        </select>
        <select className="input-field max-w-xs" value={active} onChange={(e) => setActive(e.target.value)} data-testid="staff-active-filter">
          <option value="all">All statuses</option>
          <option value="active">Active</option>
          <option value="inactive">Inactive</option>
        </select>
      </div>

      <div className="surface-card overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-stone-50 text-xs uppercase tracking-widest text-stone-500">
            <tr>
              <th className="text-left px-4 py-3">Name</th>
              <th className="text-left px-4 py-3">Email</th>
              <th className="text-left px-4 py-3">Role</th>
              <th className="text-left px-4 py-3">Status</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {list.map((s) => (
              <tr key={s.id} className="border-t border-stone-200" data-testid={`staff-row-${s.id}`}>
                <td className="px-4 py-3">{s.name}</td>
                <td className="px-4 py-3 text-stone-600">{s.email}</td>
                <td className="px-4 py-3">{s.role}</td>
                <td className="px-4 py-3">
                  <span className={`pill ${s.active ? "text-emerald-900 border-emerald-900" : "text-stone-500 border-stone-400"}`}>
                    {s.active ? "Active" : "Inactive"}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  <Link to={`/admin/staff/${s.id}`} className="btn-ghost text-sm border border-stone-300" data-testid={`edit-staff-${s.id}`}>Edit</Link>
                </td>
              </tr>
            ))}
            {list.length === 0 && <tr><td colSpan={5} className="text-center py-10 text-stone-400">No staff match these filters.</td></tr>}
          </tbody>
        </table>
      </div>
    </div>
  );
}
