import React, { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { Settings, RefreshCcw, Sparkles, Menu, X } from "lucide-react";
import Logo from "@/components/Logo";
import { useApp } from "@/state/store";

const CLIENT_NAV = [
  { to: "/", label: "Home" },
  { to: "/availability", label: "Availability" },
  { to: "/plan", label: "Wedding Plan" },
  { to: "/status", label: "Request Status" },
  { to: "/help", label: "Help" },
];

const COORD_NAV = [
  { to: "/coord", label: "Home" },
  { to: "/coord/queue", label: "Requests" },
  { to: "/coord/venue", label: "Availability" },
  { to: "/coord/help", label: "Help" },
];

const ADMIN_NAV = [
  { to: "/admin", label: "Home" },
  { to: "/admin/staff", label: "Staff Accounts" },
  { to: "/admin/help", label: "Help" },
];

function RoleSwitcher() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const roles = [
    { id: "client", label: "Client", to: "/" },
    { id: "coordinator", label: "Coordinator", to: "/coord" },
    { id: "administrator", label: "Administrator", to: "/admin" },
  ];
  return (
    <div
      className="flex items-center gap-1 border border-stone-300 bg-stone-50/80 rounded-sm p-0.5"
      data-testid="role-switcher"
    >
      <span className="text-[10px] tracking-[0.2em] uppercase text-stone-500 pl-2 pr-1">
        View as
      </span>
      {roles.map((r) => (
        <button
          key={r.id}
          data-testid={`role-${r.id}`}
          onClick={() => {
            dispatch({ type: "SET_VIEW", view: r.id });
            navigate(r.to);
          }}
          className={`text-xs px-3 py-1.5 rounded-sm transition-colors ${
            state.activeView === r.id
              ? "bg-emerald-900 text-ivory text-stone-50"
              : "text-stone-700 hover:bg-stone-200"
          }`}
          style={
            state.activeView === r.id
              ? { background: "#0A3D2D", color: "#FDFBF7" }
              : {}
          }
        >
          {r.label}
        </button>
      ))}
    </div>
  );
}

function PresentationControls() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  const loadScenarios = [
    { id: "REQ-10241", label: "Under Review · Caldwell" },
    { id: "REQ-10242", label: "Needs Info · Mendes" },
    { id: "REQ-10243", label: "Confirmed · Shah" },
    { id: "REQ-10244", label: "Cannot Fulfil · Fletcher" },
    { id: "REQ-DRAFT-01", label: "Draft · Lin" },
  ];

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          data-testid="presentation-controls-btn"
          className="flex items-center gap-1.5 text-xs px-3 py-1.5 border border-stone-300 rounded-sm hover:bg-stone-100 transition-colors"
        >
          <Settings className="w-3.5 h-3.5" />
          Presentation
        </button>
      </PopoverTrigger>
      <PopoverContent
        align="end"
        className="w-80 bg-white border border-stone-200 rounded-sm shadow-[0_8px_30px_rgb(0,0,0,0.06)] p-4"
        data-testid="presentation-panel"
      >
        <div className="text-[10px] tracking-[0.25em] uppercase text-stone-500 mb-2">
          Load Example
        </div>
        <div className="space-y-1 mb-4">
          {loadScenarios.map((s) => (
            <button
              key={s.id}
              data-testid={`load-${s.id}`}
              onClick={() => {
                dispatch({ type: "SET_ACTIVE_REQUEST", id: s.id });
                toast.success(`Loaded ${s.label}`);
                if (state.activeView === "client") navigate("/status");
                else if (state.activeView === "coordinator")
                  navigate(`/coord/review/${s.id}`);
                setOpen(false);
              }}
              className="w-full text-left text-sm py-1.5 px-2 rounded-sm hover:bg-stone-100 transition-colors"
            >
              {s.label}
            </button>
          ))}
        </div>

        <div className="divider-gold mb-3" />

        <div className="text-[10px] tracking-[0.25em] uppercase text-stone-500 mb-2">
          Next Payment Outcome
        </div>
        <div className="flex gap-1 mb-4">
          {["success", "declined", "unknown"].map((o) => (
            <button
              key={o}
              data-testid={`payment-${o}`}
              onClick={() =>
                dispatch({ type: "SET_PRESENTATION", patch: { paymentOutcome: o } })
              }
              className={`text-xs px-2.5 py-1 rounded-sm border capitalize transition-colors ${
                state.presentation.paymentOutcome === o
                  ? "bg-emerald-900 text-stone-50 border-emerald-900"
                  : "border-stone-300 hover:bg-stone-100"
              }`}
              style={
                state.presentation.paymentOutcome === o
                  ? { background: "#0A3D2D", color: "#FDFBF7" }
                  : {}
              }
            >
              {o}
            </button>
          ))}
        </div>

        <div className="text-[10px] tracking-[0.25em] uppercase text-stone-500 mb-2">
          Next Refund Outcome
        </div>
        <div className="flex flex-wrap gap-1 mb-4">
          {["pending", "completed", "failed", "unknown"].map((o) => (
            <button
              key={o}
              data-testid={`refund-${o}`}
              onClick={() =>
                dispatch({ type: "SET_PRESENTATION", patch: { refundOutcome: o } })
              }
              className={`text-xs px-2.5 py-1 rounded-sm border capitalize transition-colors ${
                state.presentation.refundOutcome === o
                  ? "bg-emerald-900 text-stone-50 border-emerald-900"
                  : "border-stone-300 hover:bg-stone-100"
              }`}
              style={
                state.presentation.refundOutcome === o
                  ? { background: "#0A3D2D", color: "#FDFBF7" }
                  : {}
              }
            >
              {o}
            </button>
          ))}
        </div>

        <label className="flex items-center gap-2 mb-4 cursor-pointer">
          <input
            type="checkbox"
            data-testid="toggle-conflict"
            checked={state.presentation.forceConflict}
            onChange={(e) =>
              dispatch({
                type: "SET_PRESENTATION",
                patch: { forceConflict: e.target.checked },
              })
            }
            className="accent-emerald-900"
          />
          <span className="text-sm">Trigger date conflict on next confirmation</span>
        </label>

        <div className="divider-gold mb-3" />

        <button
          data-testid="reset-all-btn"
          onClick={() => {
            if (window.confirm("Reset all demo data to original seed?")) {
              dispatch({ type: "RESET" });
              toast.success("Demo data restored");
              navigate("/");
              setOpen(false);
            }
          }}
          className="w-full flex items-center justify-center gap-2 text-sm py-2 border border-red-800 text-red-800 hover:bg-red-50 rounded-sm transition-colors"
        >
          <RefreshCcw className="w-3.5 h-3.5" />
          Reset All Data
        </button>
      </PopoverContent>
    </Popover>
  );
}

function SignOut() {
  const { state, dispatch } = useApp();
  const navigate = useNavigate();
  return (
    <button
      data-testid="sign-out-btn"
      title={state.session?.email}
      className="text-[11px] tracking-[0.15em] uppercase px-3 py-1.5 border border-stone-300 rounded-sm text-stone-600 hover:border-stone-500 hover:text-stone-900 transition-colors"
      onClick={() => {
        dispatch({ type: "LOGOUT" });
        navigate("/login");
      }}
    >
      Sign out
    </button>
  );
}

export default function Shell({ children }) {
  const { state } = useApp();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const nav =
    state.activeView === "coordinator"
      ? COORD_NAV
      : state.activeView === "administrator"
        ? ADMIN_NAV
        : CLIENT_NAV;

  const contextLabel =
    state.activeView === "coordinator"
      ? "Staff · Coordinator"
      : state.activeView === "administrator"
        ? "Staff · Administrator"
        : "Member Experience";

  return (
    <div className="min-h-screen flex flex-col" data-testid="app-shell">
      {/* Top admin bar: role switcher + presentation controls */}
      <div className="border-b border-stone-200 bg-stone-50/70 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-2 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2 text-[11px] tracking-[0.2em] uppercase text-stone-500">
            <Sparkles className="w-3 h-3 text-amber-600" />
            {contextLabel}
          </div>
          <div className="flex items-center gap-2">
            <RoleSwitcher />
            <PresentationControls />
            <SignOut />
          </div>
        </div>
      </div>

      {/* Main header */}
      <header className="border-b border-stone-200 bg-white/85 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-6">
          <Link to="/" data-testid="brand-home-link">
            <Logo />
          </Link>
          <nav className="hidden md:flex items-center gap-1" data-testid="main-nav">
            {nav.map((n) => {
              const active =
                n.to === "/"
                  ? location.pathname === "/"
                  : location.pathname.startsWith(n.to);
              return (
                <Link
                  key={n.to}
                  to={n.to}
                  data-testid={`nav-${n.label.toLowerCase().replace(/\s+/g, "-")}`}
                  className={`px-3 py-2 text-sm rounded-sm transition-colors ${
                    active
                      ? "text-emerald-900 font-medium"
                      : "text-stone-600 hover:text-emerald-900"
                  }`}
                  style={active ? { color: "#0A3D2D" } : {}}
                >
                  {n.label}
                </Link>
              );
            })}
          </nav>
          <button
            className="md:hidden p-2 rounded-sm hover:bg-stone-100"
            onClick={() => setMobileOpen((x) => !x)}
            data-testid="mobile-menu-btn"
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        {mobileOpen && (
          <div className="md:hidden border-t border-stone-200 bg-white">
            <div className="max-w-7xl mx-auto px-6 py-3 flex flex-col">
              {nav.map((n) => (
                <Link
                  key={n.to}
                  to={n.to}
                  onClick={() => setMobileOpen(false)}
                  className="py-2 text-sm text-stone-700"
                >
                  {n.label}
                </Link>
              ))}
            </div>
          </div>
        )}
      </header>

      {/* Page */}
      <main className="flex-1" data-testid="page-main">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 mt-16 bg-stone-50/70">
        <div className="max-w-7xl mx-auto px-6 py-10 flex flex-col md:flex-row justify-between gap-6">
          <div>
            <Logo size={34} />
            <p className="text-xs text-stone-500 mt-3 max-w-md">
              Hosting weddings and private celebrations beneath Vermont&apos;s oldest pines
              since 1962.
            </p>
          </div>
          <div className="text-xs text-stone-500 space-y-1">
            <div>42 Pine Ridge Drive · Ashford, VT 05873</div>
            <div>events@emeraldpines.club · (802) 555-0162</div>
            <div className="text-stone-400">
              © 2026 Emerald Pines Country Club. All rights reserved.
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
