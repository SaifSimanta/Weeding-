import React from "react";
import { STATUS_LABEL, STATUS_TONE } from "@/state/store";

export default function StatusBadge({ status, testId }) {
  return (
    <span
      className={`pill ${STATUS_TONE[status] || "text-stone-600 border-stone-300 bg-stone-50"}`}
      data-testid={testId || `status-${status}`}
    >
      {STATUS_LABEL[status] || status}
    </span>
  );
}

export function Timeline({ items }) {
  return (
    <ol className="relative border-l border-stone-200 pl-5 space-y-4" data-testid="timeline">
      {items.map((t, i) => (
        <li key={i} className="relative">
          <span
            className="absolute -left-[22px] top-1 w-2.5 h-2.5 rounded-full"
            style={{ background: i === items.length - 1 ? "#D4AF37" : "#0A3D2D" }}
          />
          <div className="text-sm font-medium text-stone-800">{t.label}</div>
          <div className="text-xs text-stone-500">{t.at}</div>
        </li>
      ))}
    </ol>
  );
}
