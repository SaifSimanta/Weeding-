import React from "react";

export default function Logo({ size = 44, variant = "dark" }) {
  const emerald = variant === "dark" ? "#0A3D2D" : "#FDFBF7";
  const gold = "#D4AF37";
  return (
    <div className="flex items-center gap-3" data-testid="brand-logo">
      <svg
        width={size}
        height={size}
        viewBox="0 0 64 64"
        aria-label="Emerald Pines Country Club logo"
      >
        {/* Pine tree silhouette */}
        <path
          d="M32 6 L22 22 L27 22 L18 36 L25 36 L14 52 L50 52 L39 36 L46 36 L37 22 L42 22 Z"
          fill={emerald}
        />
        {/* trunk */}
        <rect x="30" y="52" width="4" height="6" fill={emerald} />
        {/* gold wedding band entwined */}
        <ellipse
          cx="32"
          cy="44"
          rx="16"
          ry="5"
          fill="none"
          stroke={gold}
          strokeWidth="1.6"
          strokeLinecap="round"
        />
        <ellipse
          cx="32"
          cy="44"
          rx="16"
          ry="5"
          fill="none"
          stroke={emerald}
          strokeWidth="1.6"
          strokeDasharray="4 60"
          strokeDashoffset="-16"
        />
      </svg>
      <div className="leading-tight">
        <div
          className="font-serif text-xl tracking-tight"
          style={{ color: variant === "dark" ? "#0A3D2D" : "#FDFBF7" }}
        >
          Emerald Pines
        </div>
        <div
          className="text-[10px] tracking-[0.3em] uppercase"
          style={{ color: variant === "dark" ? "#A37C17" : "#D4AF37" }}
        >
          Country Club · Est. 1962
        </div>
      </div>
    </div>
  );
}
